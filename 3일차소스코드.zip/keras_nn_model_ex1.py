import numpy as np
from keras.models import Sequential
from keras.layers import Dense

# data
x_train = [1, 2, 3, 4]
y_train = [2, 4, 6, 8]

# model
model = Sequential()
model.add(Dense(1, input_dim = 1))

# learning methods
model.compile(loss='mse', optimizer='adam')

# training
model.fit(x_train, y_train, epochs=5000, verbose=1) # verbose, 1: show the training, 0: don't show the training
model.summary()

# evaluation
y_predict = model.predict(np.array([5,6,7])) # model result prediction when the inputs are 5, 6, and 7
print(y_predict)
