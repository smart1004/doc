#!/usr/bin/env python
# coding: utf-8

# In[ ]:




"""
기본적인 내용

DataFrame은 엑셀 sheet 같이 행과 열(column)로 구성된 사각형 모양의 표(Table) 처럼 생겼습니다.
열(column)은 칼럼, 속성(Attribute), 변수(Variable)라고도 합니다.
이 데이터는 속성이 몇개야? 하고 하면 열(칼럼)이 몇개야? 라고 묻고 있다고 생각하면 됩니다. 

"""
# In[1]:


import pandas as pd


# In[ ]:





# In[4]:


# data source: 광고정보센터(https://www.adic.or.kr/)
df = pd.read_csv("./2020_06_광고주광고비.csv")  
# usecols = ["회사명", TV", "라디오"]


# In[8]:


type(df) # DataFrame


# In[6]:


df.head()


# In[7]:


df.columns  # 열 리스트


# In[ ]:





# In[16]:


df[1:2] #두번째 것만 선택(select)


# In[18]:


df[0:2] # 1~2번째 것만 선택(select)


# In[ ]:





# In[ ]:


# iloc[row slicing, column slicing]
surveys_df.iloc[0:3, 1:4]


# In[12]:


df[:1]


# In[14]:


df[:3] #앞에서 부터 3개만 보고 싶다


# In[ ]:





# In[27]:


# 광고비가 높은 순으로 상위 10개를 선택(select)
df1=df.sort_values(by=['전체'], ascending=False) # .reset_index(drop=True)
df1


# In[25]:


df1[0:10] # 광고비가 높은 순으로 상위 10개를 선택(select)


# In[28]:


df2 = df1[0:10]  # 새로운 변수에 저장


# In[31]:


df2.describe()


# In[32]:


df2.TV.mean() # df2["TV"].mean()


# In[34]:


df2.라디오.mean()


# In[35]:


df2.전체.mean()


# In[ ]:





# **팁**  
# pd.read_ 까지만 입력하고 Tab키를 누러면 자동완성 기능에 의해 read로 시작하는 함수를 보여준다.

# **엑셀에서 읽어오기**

# In[50]:


df3 = pd.read_excel("./2020_06_광고주광고비.xlsx") 


# In[51]:


df3


#   
# **usecols 사용**  
# 왜 사용하는가? 칼럼이 1000개쯤 된다면, 꼭 필요한 칼럼만 선택해서 불러오는 것이 좋다.  
# 처리대상 칼럼이 많은 수록 컴퓨터가 느리다.  
# 컴퓨터가 처리하는데 빠르다. 처리 대상이 작기 때문이다.

# In[39]:


df4 = pd.read_excel("./2020_06_광고주광고비.xls", usecols = ["회사명", "TV", "라디오"]) 
df4


# In[41]:


df4.to_csv('./df4.csv', encoding='euc-kr') # csv로 저장하기


# In[47]:


# 엑셀로 저장하기, 데이터양이 많으면 csv로 저장하세요. 
# 더 빠릅니다.
df4.to_excel('./df4.xlsx', encoding='euc-kr', index=False) 


# In[48]:


df5 = pd.read_excel("./df4.xlsx") # 저장한 엑셀파일을 읽어 봅시다. 잘 저장 되었네요.


# In[49]:


df5


# In[ ]:




