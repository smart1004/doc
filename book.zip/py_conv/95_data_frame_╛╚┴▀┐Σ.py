#!/usr/bin/env python
# coding: utf-8

# In[ ]:





# In[17]:


# .value_counts()를 사용하면 
# 회사명 컬럼 내에 존재하는 각각의 값의 개수를 알 수 있습니다.
# 전체 회사명이 500개이고 value_counts()의 Length가 500 회사명에는 중복이 없음을 알수 있다.
df['회사명'].value_counts()


# In[ ]:


df['year'].value_counts(normalize=True)


# In[ ]:


# .unique()를 사용하면 
# year 컬럼 내에 존재하는 각각의 값의 종류를 알 수 있습니다.
df['year'].unique()


# In[ ]:





# In[19]:


# normalize 옵션을 사용하면 % 로도 표현이 가능합니다.
# 각 범주별로 몇 %를 차지하는지 알수 있다
df['회사명'].value_counts(normalize=True)


# In[21]:


1/500


# In[ ]:





# In[ ]:





# In[ ]:


https://www.delftstack.com/ko/howto/python-pandas/how-to-get-the-sum-of-pandas-column/


# In[3]:


import pandas as pd

df = pd.DataFrame(
    {
        'Date': 
             ['08/09/2018', 
              '10/09/2018', 
              '08/09/2018', 
              '10/09/2018'],
        'Fruit': 
             ['Apple', 
              'Apple', 
              'Banana', 
              'Banana'],
        'Sale':
             [34,
              12,
              22,
              27]
    })


# In[4]:


# 과일 당 판매액의 누적 합계를 계산하고 모든 날짜에 대해 다음을 수행 할 수 있습니다.
# 위의 코드를 실행하면 다음과 같은 결과를 얻을 수 있으며 각 날짜의 누적 과일 수를 보여줍니다.
print(df.groupby(by=['Fruit','Date']).sum().groupby(level=[0]).cumsum())


# In[ ]:





# In[ ]:





# In[1]:


import pandas as pd
equiv = {7001:1, 8001:2, 9001:3}
df = pd.DataFrame( {"A": [7001, 8001, 9001, 10000]} )
df["B"] = df["A"].map(equiv)
print(df)
#        A   B
# 0   7001   1
# 1   8001   2
# 2   9001   3
# 3  10000 NaN


# In[ ]:




