#!/usr/bin/env python
# coding: utf-8

# In[1]:


#파생변수 추가하기


# In[ ]:





# In[2]:


import pandas as pd


# In[3]:


# data source: 광고정보센터(https://www.adic.or.kr/)
df = pd.read_csv("./2020_06_광고주광고비.csv")  


# In[4]:


df.head()


# In[ ]:





# In[ ]:





# ### 칼럼을 삭제 후에 추가 해보자  
#   

# In[5]:


df = df.drop(columns = ['전체']) 


# In[6]:


df.head()


# In[7]:


df['전체1'] = df.TV+df.라디오+df.신문+df.잡지


# In[8]:


df.head()


# In[9]:


total = df['TV'].sum() #열의 총합 구해보자
print ("TV column sum:",total)


# In[ ]:





# In[10]:


# 광고비_평균을 구해, 칼럼을 추가
df['광고비_평균'] = (df.TV+df.라디오+df.신문+df.잡지)/4


# In[11]:


df.head()


# In[ ]:





# In[ ]:





# # 조건에 따른 다른 값을 부여하는 칼럼을 추가

# In[12]:


# https://www.delftstack.com/ko/howto/python-pandas/how-to-create-dataframe-column-based-on-given-condition-in-pandas/


# ## matplotlib 설정을 먼저 한다. 가이드를 제시한다. 윈도우를 기준으로 한다.

# In[ ]:


# 하고자 하는 미션은 회사별 광고비 총액(df['전체1'])을 기준으로 3가지로 분류하려 한다.
# 대, 중, 소와 같은 행태로 분류라려 한다.


# In[ ]:





# In[15]:


import matplotlib.pyplot as plt
import seaborn as sns


# In[18]:


print(df['전체1'].describe())


# In[19]:


plt.figure(figsize=(9, 8))
sns.distplot(df['전체1'], color='g', bins=10, hist_kws={'alpha': 0.4});


# In[22]:


# 숫자가 크서 가독성이 떨어진다. 백만원으로 나누어 준다.
plt.figure(figsize=(9, 8))
sns.distplot(df['전체1']/1000000, color='g', bins=50, hist_kws={'alpha': 0.4});


# In[ ]:


# 조건에 따른 다른 값을 부여하는 칼럼을 추가


# In[ ]:


4000000 이상
1000000 이상 ~ 4000000 미만
1000000 미만


# In[24]:


import numpy as np


# In[25]:


conditionlist = [
    (df['전체1'] >= 4000000) ,
    (df['전체1'] >= 1000000) & (df['전체1'] <4000000),
    (df['전체1'] < 1000000)]
category = ['High', 'Mid', 'Low']
df['광고비_규모_구분'] = np.select(conditionlist, category, default='Not Specified')


# In[26]:


df.head()


# In[27]:


df['광고비_규모_구분'].value_counts() # 4000000 이상이 8개 업체다


# In[28]:


df['광고비_규모_구분'].value_counts(normalize=True)


# In[ ]:





# # 06_집단별로 요약하기

# In[31]:


df.head()


# In[43]:


df_sum = df.groupby('광고비_규모_구분').sum().reset_index(drop=False) #집단별 합계 산출


# In[44]:


df_sum


# In[45]:


df_mean = df.groupby('광고비_규모_구분').mean().reset_index(drop=False) # 평균 산출


# In[46]:


df_mean


# In[ ]:




