#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# 06-7 데이터 합치기 할 차례다
# 151


# In[1]:


import pandas as pd


# In[33]:


df1 = pd.read_excel("./일별판매 데이터.xlsx", sheet_name="1월") 


# In[34]:


df1


# In[15]:


df2 = pd.read_excel("./일별판매 데이터.xlsx", sheet_name="2월") 


# In[16]:


df2


# # 세로로 합치기, 행  
# - 1월, 2월 합친다  
# - 제약조건: 칼럼의 순서가 동일해야 한다.

# In[17]:


df = pd.concat([df1, df2], axis=0).reset_index(drop=True)
df


# ## 팁 
# - 판매제품별 각 날짜의 누적 판매수량 수를 보여줍니다.

# In[40]:


df.groupby(by=['판매제품','Date']).sum().groupby(level=[0]).cumsum()


# In[ ]:





# # 가로로 합치기  
# - 제약조건: 두개의 테이블(표)의 행의 순서와 개수가 일치해야 한다.

# In[19]:


df3 = pd.read_excel("./일별판매 데이터.xlsx", sheet_name="1월_추가정보") 


# In[20]:


df3 # 주문번호 순서


# In[ ]:





# In[21]:


df1


# In[22]:


df_1_3 = pd.concat([df1.reset_index(drop=True), df3], axis=1)  # c bind


# In[23]:


df_1_3


# In[25]:


df_1_3.drop(columns=['주문번호'], inplace=True)
df_1_3


# In[ ]:





# # 엑셀의 vlookup은 어떻게 하는가?

# In[35]:


df1


# In[36]:


df_사원정보 = pd.read_excel("./일별판매 데이터.xlsx", sheet_name="사원정보") 
df_사원정보


# In[37]:


# how="left"
# 두 데이터프레임 중 먼저 기술된, left에 위치한 df1을 기준으로 추출한다.
# df_사원정보에 lookup해 존재하면 df_사원정보의 칼럼을 추출하고 없으면 NaN을 표시
df_merge1 = pd.merge(df1, df_사원정보, on="판매사원ID", how="left") 
df_merge1


# In[38]:


df_merge2 = pd.merge(df1, df_사원정보, on="판매사원ID", how="outer")  
df_merge2


# In[ ]:




