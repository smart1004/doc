#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# 06_집단별로 요약하기


# In[ ]:





# In[1]:


import pandas as pd

df = pd.DataFrame(
    {
        'Date': 
             ['08/09/2018', 
              '10/09/2018', 
              '08/09/2018', 
              '10/09/2018'],
        'Fruit': 
             ['Apple', 
              'Apple', 
              'Banana', 
              'Banana'],
        'Sale':
             [34,
              12,
              22,
              27]
    })


# In[3]:


df


# In[2]:


# 과일 당 판매액의 누적 합계를 계산하고 모든 날짜에 대해 다음을 수행 할 수 있습니다.
# 위의 코드를 실행하면 다음과 같은 결과를 얻을 수 있으며 각 날짜의 누적 과일 수를 보여줍니다.
print(df.groupby(by=['Fruit','Date']).sum().groupby(level=[0]).cumsum())


# In[ ]:





# In[ ]:




