#!/usr/bin/env python
# coding: utf-8
08 데이터 정제, 결측치 이상치 제거
161 페이지
# In[ ]:





# In[1]:


import pandas as pd


# In[4]:


df1 = pd.read_csv("./500_Person_Gender_Height_Weight_Index3.csv", encoding ="euc-kr") 


# In[5]:


df1


# In[6]:


df1.info()

511 entries
Height    505 <-- null 6개
Weight    506 <-- null 5개
# In[ ]:





# In[7]:


qq = df1.isnull().sum().to_frame('count1')
print('check null count: ', qq[qq.count1 > 0] )


# In[ ]:




