#!/usr/bin/env python
# coding: utf-8

# In[143]:


### import xgboost as xgb
from sklearn.metrics import mean_squared_error
import time
import pandas as pd
import numpy as np
from IPython.display import Image as dimage
import glob
from PIL import Image
#한글 폰트 사용
from matplotlib import font_manager,rc
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
#폰트 경로
font_path = "/usr/share/fonts/nhn-nanum/NanumGothic.ttf"


# In[144]:


#폰트 이름 얻어오기
font_name = font_manager.FontProperties(fname=font_path).get_name()
font_name


# In[145]:


fontprop = font_manager.FontProperties(fname=font_path, size=11)


# In[146]:


#font 설정
matplotlib.rc('font',family=font_name)


# In[147]:


# jupyter notebook 내 그래프를 바로 그리기 위한 설정
get_ipython().run_line_magic('matplotlib', 'inline')

# unicode minus를 사용하지 않기 위한 설정 (minus 깨짐현상 방지)
plt.rcParams['axes.unicode_minus'] = False


# In[148]:


import matplotlib as mpl

#font 설정 파일 위치 출력
mpl.matplotlib_fname()


# In[149]:


#font 설정
# matplotlib.rc('font',family=font_name)


# In[150]:


get_ipython().run_line_magic('matplotlib', 'inline')
plt.style.use('bmh')
from collections import Counter


# In[9]:


#차트 이미지를 계산한다
def calSize(files):
    size_x =[]
    size_y=[]
    for file in files:
        image = Image.open(file)
        size_x.append(image.size[0])
        size_y.append(image.size[1])
    x_min = min(size_x)
    y_min = min(size_y)
    tot_x_size=x_min*len(files)        
    #print('size_x, size_y', size_x, size_y)
    #print('tot_x_size, x_min, y_min',tot_x_size, x_min, y_min)
    return x_min, y_min, tot_x_size

def resizeToMin(files, x_min, y_min, tot_x_size):
    file_lst=[]
    for file in files:
        image = Image.open(file)
        resized_file = image.resize((x_min,y_min))
        file_lst.append(resized_file )
        #resized_file.show() 
    #return file_lst, x_min, y_min, tot_x_size        
    return file_lst

# path1='./png/jointplot_y/'
def mkdir_rm(path1):
    import shutil, os    
    if os.path.exists(path1):
        shutil.rmtree(path1)
    os.mkdir(path1)  


# In[10]:


# 차트를 압축한다
def zip1(targ_dir, zipfileNm):
    import os;import zipfile
    #zipfileNm = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/pairplot_y.zip'
    my_zip = zipfile.ZipFile(zipfileNm, 'w')
    #targ_dir = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png'
    for folder, subfolders, files in os.walk(targ_dir): 
        for file in files:
            if file.endswith('.png'):
                my_zip.write(os.path.join(folder, file), os.path.relpath(os.path.join(folder,file), targ_dir), 
                                  compress_type = zipfile.ZIP_DEFLATED) 
    my_zip.close()

# targ_dir = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/jointplot_y_merge2'
# zipfileNm = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/jointplot_y_merge2.zip'
# zip1(targ_dir, zipfileNm) 

# targ_dir = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/pairplot'
# zipfileNm = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/pairplot_y.zip'
# zip1(targ_dir, zipfileNm)


# In[11]:


def mergeImageVertical_main_new(input_dir, savePath):
    target_dir=input_dir
    #target_dir = r'./png/jointplot_y/'
    files=glob.glob(target_dir +"*.*")

    files=np.sort(files).tolist()
    print('len(files): ', len(files))

    #savePath="./png/jointplot_y_merge/"
    mkdir_rm(savePath)

    nMergeFiles=5;
    imageMergeVerticalServ(files, nMergeFiles, savePath) #옆으로 5개를 붙힌다


def mergeImageHorizontal_main_new(input_dir, png_dir, savePath):
    #savePath = png_dir + savePathLeaf + '/'
    mkdir_rm(savePath)

    #input_dir = png_dir+'/scatterplot_y_merge/'
    files=glob.glob(input_dir +"*.*")
    files=np.sort(files).tolist()
    print('len(files) : ', len(files))

    nMergeFiles=3
    imageMergeHorizontalSrv(files, nMergeFiles, savePath) #수직으로 3개 합치기

    targ_dir = png_dir+ savePathLeaf #'/jointplot_y_merge2'
    zipfileNm =png_dir+ savePathLeaf+'.zip' #'/jointplot_y_merge2_.zip'
    zip1(targ_dir, zipfileNm)


# ## data 불러오기

# In[12]:


# data_dir='./'
# df_in1 = pd.read_csv(data_dir + "mag_loss.csv",  encoding='euc-kr')
# data=df_in1
# data = data.sort_values(by=['m_작업계상일자'])


# In[13]:


data_dir='./'
df_in1 = pd.read_excel(data_dir + "DNL1_Main_적재.xlsx",  encoding='euc-kr')
df_in2 = pd.read_excel(data_dir + "DNL1_EBSD.xlsx",  encoding='euc-kr')


# In[14]:


data = df_in1.merge(df_in2, left_on='재료번호', right_on='소재번호')


# In[ ]:





# In[ ]:





# In[15]:


# Counter(data.m_작업계상일자)
Counter(data.작업계상일자)
# data.m_작업계상일자.value_counts() #sort가 안됨


# In[ ]:





# In[16]:


data.info()


# In[17]:


# data.head()


# # NaN values 처리
# ## na/None를 제거한다. 대상: 숫자형변수의 na
# 데이터도 별로 없는데, 과연지우는게 맞는가?  m_산화량, m_침질량 <--주요변수인가?
# 유선영씨에게 물어보자. 아래 삭제하려는 애들중 중요하게 생각하시는 애들이 있는지?

# In[ ]:





# In[18]:


data = data.dropna(axis=0, subset=['보증철손'])


# In[19]:


data_origin = data.copy()


# In[20]:


data.head()


# In[21]:


## data.isnull().sum().sort_values(ascending=False)[:30]
qq = data.isnull().sum().to_frame('count1')
print('check null count: ', qq[qq.count1 > 0] )


# ## 이 변수는 살리자. 산화량, 침질량, 연속작업
# m_TensionReel구분??????

# In[23]:


print("data -  rows:",data.shape[0]," columns:", data.shape[1])
drop_cols=qq[qq.count1>0].index.tolist()
# drop_cols =['Unnamed: 0','m_연속작업']
data=data.drop(drop_cols, axis=1)


# In[24]:


drop_cols[:10]


# In[25]:


print("droped rows:",data.shape[0]," columns:", data.shape[1])


# ### row수보다 칼럼이 더 많다.. 칼럼의 3배는 되야 하는데~~

# In[26]:


data.describe() # 요약 통계량


# In[27]:


print(data['보증철손'].describe())
plt.figure(figsize=(9, 8))
sns.distplot(data['보증철손'], color='g', bins=100, hist_kws={'alpha': 0.4});


# In[28]:


len(data)


# In[29]:


data = data.drop(data[data.보증철손 == 0].index)


# In[30]:


len(data)


# In[31]:


# 0.86에 너무 많다 저게 의미하는 바가 뭔가


# In[ ]:





# ###  skewed(left/right)?  outliers lies above?

# In[ ]:





# In[32]:


list(set(data.dtypes.tolist()))


# # number to category

# In[33]:


bins = [0, 0.85, 0.89]
names = ['a0.84이하', 'b0.84초과_0.88이하', 'c0.88초과']

d = dict(enumerate(names, 1))
#Counter({'0.84초과_0.88이하': 97, '0.88초과': 62, '0.84이하': 25})
data['보증철손범주'] = np.vectorize(d.get)(np.digitize(data['보증철손'], bins))


# In[34]:


# 종속 변수의 분포 확인
Counter(data.보증철손범주)


# In[35]:


data['보증철손범주'].value_counts().plot(kind='bar') 
plt.show()


# In[36]:


# fig , ax = plt.subplots(figsize=(6,4))
# sns.countplot(x='보증철손범주', data=data)
# plt.title("Count of target")
# plt.show()


# In[ ]:





# In[37]:


''' Encoder '''
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import LabelBinarizer
columns_le =["보증철손범주"]
le_dict = {col: LabelEncoder() for col in columns_le}
for col in columns_le:
    data[col+'_LE']=le_dict[col].fit_transform(data[col])

for col in columns_le:
    for i in range(len(le_dict[col].classes_)):
        print(col, i, le_dict[col].inverse_transform([i])) #decoder

data.rename(columns={"보증철손범주_LE" : "Class"}, inplace=True)


# In[ ]:





# ## 불필요 변수 삭제

# In[38]:


data.head()


# In[39]:


# data.columns.tolist()


# In[40]:


#drop_etc = ['Unnamed: 0','m_작업계상일자','m_년월','m_월일']
drop_etc = ['조회일','조회일시','작업계상일자','작업시작일시','작업완료일시','년월','월일','이미지_개수']
data_origin22 = data.copy()
data=data.drop(drop_etc, axis=1)


# In[ ]:





# In[ ]:





# # 숫자형만 eda 실시

# In[41]:


# 숫자형만 eda 실시
df_num = data.select_dtypes(include = ['float64', 'int64'])
# df_num.head()
num_cols=df_num.columns.tolist()
# num_cols[:20]
df_num.info()


# In[42]:


data.info()


# In[ ]:





# In[43]:


# df_num[num_cols[10:20]]
# df_num[num_cols[1:3]].hist(figsize=(16, 20), bins=50, xlabelsize=8, ylabelsize=8); # ; avoid having the matplotlib verbose informations


# In[ ]:





# # 상관계수 구하기

# In[44]:


df_num_corr = df_num.corr()['보증철손'][:-1] # -1 because the latest row is '보증철손'
sr_golden_features = df_num_corr[abs(df_num_corr) > 0.00000001].sort_values(ascending=False) #golden_features_list
print("There is {} strongly correlated values with 보증철손:\n{}".format(len(sr_golden_features), sr_golden_features))


# In[45]:


df_num_corr.to_csv('./num_corr.csv', encoding='euc-kr')


# In[46]:


type(sr_golden_features)


# In[ ]:





# In[47]:


#quantitative_features_list = ['m_RT11W.배가스온도', 'm_X1SS_BURNOFF', 'm_RT16W.배가스온도','m_화학시험소강성분N함유율', '보증철손']
# quantitative_features_list = sr_golden_features.index.tolist() #@@@@@
golden_features_list = sr_golden_features.index.tolist() #@@@@@


# In[48]:


df_golden_features = df_num[golden_features_list]
df_golden_features.head()


# In[49]:


len(golden_features_list)


# In[50]:


# features_to_analyse = [x for x in quantitative_features_list if x in golden_features_list]
# features_to_analyse.append('보증철손')
features_to_analyse=golden_features_list


# In[51]:


# df_num[features_to_analyse[:3]].hist(figsize=(16, 20), bins=50, xlabelsize=9, ylabelsize=9); # ; avoid having the matplotlib verbose informations


# # Q -> Q (Quantitative to Quantitative relationship)
# ## Let's look at their distribution.

# # 종속변수와 상관분석 -산점도
# ### 그려야 하는 변수가 너무 많아서 파일로 저장한다.

# In[52]:


df_num.columns


# In[53]:


# annot_kws=dict(stat="r")


# In[54]:


#폰트 이름 얻어오기
font_name = font_manager.FontProperties(fname=font_path).get_name()
font_name

#font 설정
matplotlib.rc('font',family=font_name)


# In[55]:


fontprop = font_manager.FontProperties(fname=font_path, size=11)


# In[56]:


font_name


# In[ ]:





# In[57]:


#여러개 이미지를 옆으로(수평방향)으로 합친다
def _imageMergeVertical(file_lst , tot_x_size, x_min, y_min, saveFileIndex, savePath):
    new_image=Image.new("RGB",(tot_x_size,y_min), (256,256,256))
    for i in range(len(file_lst)):
        area=((i*x_min), 0, (x_min*(i+1)), y_min)
        new_image.paste(file_lst[i],area)
    #new_image.show()
    #savePath="./png/jointplot_y_merge/"
    new_image.save(savePath+str(saveFileIndex).zfill(3)+ ".png", "PNG") 

# nMergeFiles(5개) 차트 이미지를 합친다. 
def imageMergeVerticalServ(files, nMergeFiles, savePath):
    nFiles=nMergeFiles
    for j in range(0, len(files), nMergeFiles):
        targetFiles = files[j:j+nFiles]
        x_min, y_min, tot_x_size = calSize(targetFiles)
        file_lst = resizeToMin(targetFiles, x_min, y_min, tot_x_size)
        saveFileIndex=j
        _imageMergeVertical(file_lst , tot_x_size, x_min, y_min, saveFileIndex, savePath)     
        #print(len(files[j:j+nFiles]))
    print("Done")   
    """
    Done
    CPU times: user 3.22 s, sys: 66.3 ms, total: 3.28 s
    Wall time: 3.53 s
    """
#여러개 이미지를 수직방향으로 합친다
def _imageMergeHorizontal(targetFiles , tot_y_size, x_min, y_min, saveFileIndex, savePath):
    new_image=Image.new("RGB",(x_min, tot_y_size), (250,250,250)) #가로 세로 
    for i in range(len(targetFiles)):
        img_01 = Image.open(targetFiles[i]) 
        new_image.paste(img_01, (0, (i*y_min)))
        #print(targetFiles[i])
    #saveDir="./png/jointplot_y_merge2/"
    new_image.save(savePath+str(saveFileIndex).zfill(3)+ ".png", "PNG")

# nMergeFiles=3; saveDir="./png/jointplot_y_merge2/"
def imageMergeHorizontalSrv(files, nMergeFiles, savePath):
    nFiles=nMergeFiles
    for j in range(0, len(files), nMergeFiles):
        targetFiles = files[j:j+nFiles]
        x_min, y_min, tot_x_size = calSize(targetFiles)
        saveFileIndex=j
        tot_y_size=y_min*nMergeFiles
        
        _imageMergeHorizontal(targetFiles , tot_y_size, x_min, y_min, saveFileIndex, savePath)
        #print(len(files[j:j+nFiles]))
    print("Done")


# # jointplot(보증철손 ) with pearsonr

# In[58]:


#savePath="./png/jointplot_y/"
def genJointplot(df_num, y, plot_columns, savePath):
    # 
    # to hide output of this cell
    from scipy.stats import pearsonr
    
    for i in range(0, len(plot_columns)):    
        #print('i',i)
        sns.set_style(style='whitegrid', rc={'font.family':font_name, 'font.serif':[font_name]}) # whitegrid white ticks dark
        g = sns.jointplot(data=df_num, x=plot_columns[i], y=y, stat_func=pearsonr, color='black', kind='reg', height=5) 
        g.savefig(savePath+"jp_y_"+str(i).zfill(3)+".png")   


# In[59]:


columns = df_num.columns.tolist()
sort_columns = np.sort(columns).tolist()


# In[60]:


len(df_num.columns)


# In[61]:


path1='./png/jointplot_y/'
mkdir_rm(path1)


# In[62]:


golden_features_list[:10]


# In[63]:


y='보증철손'
plot_columns=np.sort(golden_features_list).tolist()


# In[86]:


df_plot_columns = pd.DataFrame (plot_columns,columns=['plot_columns'])


# In[87]:


df_plot_columns.to_csv('./plot_columns.csv', encoding='euc-kr')


# In[ ]:





# In[64]:


get_ipython().run_cell_magic('capture', 'cap_out', 'genJointplot(df_num, y, plot_columns, savePath=path1)\n# del cap_out')


# In[84]:


len(plot_columns)


# In[66]:


dimage("./png/jointplot_y/jp_y_000.png")


# In[67]:


input_dir = path1
v_savePath = './png/jointplot_y_merge/'
mergeImageVertical_main_new(input_dir, v_savePath)  
# from IPython.display import Image as dimage
dimage("./png/jointplot_y_merge/000.png")


# In[68]:


png_dir = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png'
input_dir = png_dir+'/jointplot_y_merge/'
savePathLeaf='/jointplot_y_merge2'
h_savePath = png_dir + savePathLeaf + '/'    
mergeImageHorizontal_main_new(input_dir, png_dir, h_savePath)


# In[69]:


# dimage("./png/jointplot_y_merge2/000.png")


# In[ ]:





# In[ ]:




def mergeImageVertical():
    target_dir = r'./png/jointplot_y/'
    files=glob.glob(target_dir +"*.*")

    files=np.sort(files).tolist()
    print('len(files): ', len(files))

    savePath="./png/jointplot_y_merge/"
    mkdir_rm(savePath)

    nMergeFiles=5;
    imageMergeVerticalServ(files, nMergeFiles, savePath)
###########  mergeImageVertical()    
# from IPython.display import Image as dimage
dimage("./png/jointplot_y_merge/000.png")

savePath="./png/jointplot_y_merge2/"
mkdir_rm(savePath)

source_dir = r'./png/jointplot_y_merge/'
files=glob.glob(source_dir +"*.*")

files=np.sort(files).tolist()
print('len(files) : ', len(files))

nMergeFiles=3
imageMergeHorizontalSrv(files, nMergeFiles, savePath)

targ_dir = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/jointplot_y_merge2'
zipfileNm = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/jointplot_y_merge2_.zip'
zip1(targ_dir, zipfileNm)
# In[ ]:





# In[ ]:





# # scatterplot

# In[70]:


df_num.head()


# In[71]:


plot_columns=np.sort(df_num.columns.tolist()).tolist()
#plot_columns=np.sort(golden_features_list).tolist()


# In[72]:


# df_num.head()
df_num.info()


# In[73]:


len(plot_columns)


# In[74]:


# plot_columns


# In[75]:


def genScatterplot(df_num, y, plot_columns, savePath):    
    markers = {0: "*", 1: "X", 2: "."}
    palette = dict({0:'red', 1:'green', 2: 'blue'})
    for i in range(0, len(plot_columns)):    
        #print('i',i)
        plt.tight_layout(w_pad=0)
        sns.set_style(style='whitegrid', rc={'font.family':font_name, 'font.serif':[font_name]}) # whitegrid white ticks dark
        g = sns.scatterplot(x=plot_columns[i], y= y, 
                        hue='Class', # different colors by group
                        style='Class', # different shapes by group
                        s=50, # marker size
                        markers=markers,
                        palette=palette,    
                        data=df_num)
        plt.savefig(savePath+"sp_y_"+str(i).zfill(3)+".png", dpi=400)
        plt.show();plt.close()


# In[176]:


plot_columns[0]


# In[ ]:





# In[76]:


path1='./png/scatterplot_y/'
mkdir_rm(path1)


# In[77]:


get_ipython().run_cell_magic('capture', 'cap_out', 'genScatterplot(df_num, y, plot_columns, savePath=path1)')


# In[ ]:


input_dir = path1
savePath = './png/scatterplot_y_merge/'
mergeImageVertical_main_new(input_dir, savePath)  


# In[ ]:





# In[82]:


dimage(path1+"sp_y_000.png", width=600, height=300)


# In[79]:


png_dir = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png'
input_dir = png_dir+'/scatterplot_y_merge/'
savePathLeaf='/scatterplot_y_merge2'
savePath = png_dir + savePathLeaf + '/'    
mergeImageHorizontal_main_new(input_dir, png_dir, savePath)


# In[ ]:





# In[ ]:


# xxxxxxxxxxxxxx()


# In[ ]:


# df_num.columns[0:15]
# len(df_num.columns[:10])
# len(df_num.columns)


# In[ ]:





# In[ ]:





# # the outliers
# ## identify outliers 
# outlier때문에 상관계수가 부적절하게 나오는 애들을 찾는다.

# In[ ]:





# In[ ]:


sns.violinplot(x=df_num.columns[8],  data=df_num, orient="v") #y="total_bill",
plt.title("title")
plt.show()


# In[ ]:





# In[ ]:





# In[88]:


def gen_boxplot(df_num, file_index, ncols, plot_columns, savePath):    
    fig, axes = plt.subplots(nrows=1,ncols=ncols)
    plt.tight_layout(w_pad=0) #pad=1.08, h_pad=None, w_pad=None, rect=None
    fig.set_size_inches(20, 3)

    for i in range(0, len(plot_columns)):
        #print(i)    
        axes[i].set_title('  ',fontsize= 13) 
        sns.set_style(style='whitegrid', rc={'font.family':font_name, 'font.serif':[font_name]}) # whitegrid white ticks dark
        ax = sns.boxplot(data=df_num,x=plot_columns[i], orient="v",ax=axes[i])               

    plt.savefig(savePath+"bp_"+str(file_index).zfill(3)+ ".png")
    plt.show();plt.close()    
    return 'ok' 


# In[89]:


savePath="./png/boxplot/"
mkdir_rm(savePath)


# In[90]:


plot_columns=np.sort(golden_features_list).tolist()


# In[91]:


# plot_columns= plot_columns[:11]
# plot_columns


# In[92]:


len1 = len(plot_columns)
ncols=10


# In[93]:


len1


# In[94]:


get_ipython().run_cell_magic('capture', 'cap_out', "\nfor j in range(0, len1, ncols):    \n    #print(j, len1)\n    if (j+ncols)>len1: #전체 칼럼개수보다 크면\n        print('j, len1-j', j, len1-j)         \n        plot_columns_part = plot_columns[j:len1]\n        #gen_boxplot(df_num, j, len1-j, plot_columns_part, savePath)\n        gen_boxplot(df_num, j, ncols, plot_columns_part, savePath)\n    else:\n        plot_columns_part = plot_columns[j:j+ncols]\n        gen_boxplot(df_num, j, ncols, plot_columns_part, savePath)  \ndel cap_out")


# In[95]:


dimage(savePath+"bp_000.png")


# In[ ]:





# In[ ]:





# In[96]:


#savePath = r'./png/jointplot_y_merge/'
files=glob.glob(savePath +"*.*")
files=np.sort(files).tolist()
print('len(files) : ', len(files))


# In[97]:


savePath4Merge=r'./png/boxplot_merge/'
nMergeFiles=3
imageMergeHorizontalSrv(files, nMergeFiles, savePath4Merge)


# In[98]:


targ_dir = savePath4Merge #'/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/jointplot_y_merge2'
zipfileNm = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png/boxplot_merge.zip'
zip1(targ_dir, zipfileNm)


# In[ ]:





# In[ ]:





# In[ ]:





# # lineplot을 그린다

# In[ ]:




#savePath="./png/jointplot_y/"
def genJointplot(df_num, y, plot_columns, savePath):
    # 
    # to hide output of this cell
    from scipy.stats import pearsonr
    
    for i in range(0, len(plot_columns)):    
        #print('i',i)
        sns.set_style(style='whitegrid', rc={'font.family':font_name, 'font.serif':[font_name]}) # whitegrid white ticks dark
        g = sns.jointplot(data=df_num, x=plot_columns[i], y=y, stat_func=pearsonr, color='black', kind='reg', height=5) 
        g.savefig(savePath+"jp_y_"+str(i).zfill(3)+".png")   
# In[172]:


#savePath="./png/jointplot_y/"
def genLineplot(df_num, plot_columns, ind, savePath):
    fig, axes = plt.subplots(nrows=1,ncols=ncols)
    plt.tight_layout(w_pad=0) 
    fig.set_size_inches(20, 3)
    sns.set_style(style='whitegrid', rc={'font.family':font_name, 'font.serif':[font_name]}) # whitegrid white ticks dark
    palette = dict({0:'red', 1:'green', 2: 'blue'})   
    
    for i in range(0, len(plot_columns)): 
        axes[i].set_title('linep',fontsize= 16) 
        #Lineplot y축은 각 x변수들이고 x축은 df_num.index 이다.
        ax = sns.lineplot(data=df_num,x=df_num.index, y=plot_columns[i], hue='Class', style='Class',ax=axes[i], palette =palette)       
  
    plt.savefig(savePath+"lp_"+str(ind).zfill(3)+ ".png") #"./png/lineplot/lp_"+str(ind).zfill(3)+ ".png")
    plt.show();plt.close()    
    return 'ok' 


# In[ ]:





# In[173]:


ncols=5
# plot_columns=plot_columns[:6]
plot_columns=np.sort(golden_features_list).tolist()
len1 = len(plot_columns)
savePath='./png/lineplot/'


# In[ ]:





# In[174]:


get_ipython().run_cell_magic('capture', 'cap_out', "for j in range(0, len1, ncols):    \n    #print(j, len1)\n    if (j+ncols)>len1: #전체 칼럼개수보다 크면\n        print('j, len1-j', j, len1-j)         \n        plot_columns_part = plot_columns[j:len1]\n        genLineplot(df_num, plot_columns_part,  j, savePath)\n    else:\n        plot_columns_part = plot_columns[j:j+ncols]\n        genLineplot(df_num, plot_columns_part,  j, savePath)\n# del cap_out")


# In[175]:


dimage(savePath+"lp_000.png")


# In[179]:


markers = {0: "*", 1: "X", 2: "."}
palette = dict({0:'red', 1:'green', 2: 'blue'})
g = sns.scatterplot(x=df_num.index, y= '1CS2Z_H2', 
                        hue='Class', # different colors by group
                        style='Class', # different shapes by group
                        s=50, # marker size
                        markers=markers,
                        palette=palette,    
                        data=df_num)

def get_lineplot(df_num, ind, ncols=5):    
    fig, axes = plt.subplots(nrows=1,ncols=ncols)
    plt.tight_layout(w_pad=0) 
    fig.set_size_inches(20, 3)
    sns.set_style(style='whitegrid', rc={'font.family':font_name, 'font.serif':[font_name]}) # whitegrid white ticks dark
    palette = dict({0:'red', 1:'green', 2: 'blue'})
    for i in range(ind, ncols+ind, 1):
        #print(i)          
        axes[i-ind].set_title('linep',fontsize= 16) 
        ax = sns.lineplot(data=df_num,x=df_num.index, y=df_num.columns[i], hue='Class', style='Class',ax=axes[i-ind], palette =palette)       

    plt.savefig("./png/lineplot/lp_"+str(ind).zfill(3)+ ".png")
    plt.show();plt.close()    
    return 'ok' 
ind=0 #0
ncols=5 # len(df_num.columns)-ind
#get_lineplot(df_num,ind, ncols)
for ind in range(0, len(df_num.columns[:7]), 5):    
# for j in range(0, len(df_num.columns), 10):
    #print(j)
    #get_boxplot(df_num,j)
    get_lineplot(df_num,ind, ncols)
# In[ ]:





# In[ ]:





# In[100]:


# ax = sns.lineplot(x=df_num.index, y='EBSD_G_S', hue='Class', style='Class',
#                   data=df_num) 


# In[ ]:





# # C -> Q (Categorical to Quantitative relationship)

# In[101]:


df_not_num = data.select_dtypes(include = ['O'])
print('There is {} non numerical features including:\n{}'.format(len(df_not_num.columns), df_not_num.columns.tolist()))


# In[102]:


# cat_cols = ['m_연속작업', 'm_수주구분', 
#             'm_출강목표번호', 'm_재질기호', 'm_통과공장공정코드', 'm_주편지정구분', 'm_RCL', 
#             'm_LOT번호', 'm_온도조건', 'm_COF', 'm_NH3농도6', '보증철손범주']
# '소재번호', '재료번호','Charge번호',  'Slab번호', '열연코일번호',
cat_cols = [ '작업근조', '강종', '수주', '출강목표번호', '재질기호', '통과공장공정코드', '주편지정구분',
            'RCL',   '열연공장', '보증철손범주']

df_not_num=df_not_num[cat_cols]
df_not_num.head()


# In[103]:


data.head()


# In[104]:


# data["m_수주구분"]


# In[105]:


def gen_boxplot2(data, file_index, ncols, plot_columns, savePath, y):    
    fig, axes = plt.subplots(nrows=1,ncols=ncols)
    plt.tight_layout(w_pad=0) #pad=1.08, h_pad=None, w_pad=None, rect=None        
    fig.set_size_inches(20, 3)    
    for i in range(0, len(plot_columns)):
        #print(i)
        axes[i].set_title(' ',fontsize= 10) 
        sns.set_style(style='whitegrid', rc={'font.family':font_name, 'font.serif':[font_name]}) # whitegrid white ticks dark
        ax = sns.boxplot(data=data,x=plot_columns[i],y=y, ax=axes[i])    
        ax.set_xticklabels(ax.get_xticklabels(),rotation=45)
        plt.setp(ax.artists, alpha=.5, linewidth=2, edgecolor="k")        
    plt.savefig(savePath+"bp_"+str(file_index).zfill(3)+ ".png")
    plt.show();plt.close()    
    return 'ok' 


# In[ ]:





# In[106]:


#%%capture cap_out
savePath="./png/boxplot_y_cat/"
mkdir_rm(savePath)
plot_columns = cat_cols
len1 = len(plot_columns)
ncols=5
y='보증철손'
for j in range(0, len1, ncols):    
    #print(j, len1)
    if (j+ncols)>len1: #전체 칼럼개수보다 크면
        #print('j, len1-j', j, len1-j)         
        #print('plot_columns[j:len1-j]', plot_columns[j:len1-j]) 
        plot_columns_part = plot_columns[j:len1]
        gen_boxplot2(data, j, len1-j, plot_columns_part, savePath, y)
    else:
        plot_columns_part = plot_columns[j:j+ncols]
        gen_boxplot2(data, j, ncols, plot_columns_part, savePath, y)  
#del cap_out


# In[ ]:





# # false일때 뭔가 차이가 난다

# In[107]:


df_not_num.columns


# In[108]:


round(len(df_not_num.columns) / 3)


# ### countplot

# In[109]:


# fig, axes = plt.subplots(round(len(df_not_num.columns) / 3), 3, figsize=(10, 15))
# for i, ax in enumerate(fig.axes):
#     if i < len(df_not_num.columns):
#         ax.set_xticklabels(ax.xaxis.get_majorticklabels(), rotation=45)
#         sns.countplot(x=df_not_num.columns[i], alpha=0.7, data=df_not_num, ax=ax)
# fig.tight_layout()


# In[ ]:





# In[110]:


df_num.columns


# In[ ]:





# # 종속변수가 제일 뒤에 있어야 한다

# In[111]:


yy = df_num[['보증철손']]
df_num = df_num.drop(columns = ['보증철손'])
df_num = pd.concat([df_num, yy], axis=1) #


# In[112]:


df_num.head()


# In[ ]:





# In[113]:


import operator

individual_features_df = []
for i in range(0, len(df_num.columns) - 1): # -1 because the last column is 보증철손
    tmpDf = df_num[[df_num.columns[i], '보증철손']]
    tmpDf = tmpDf[tmpDf[df_num.columns[i]] != 0]
    individual_features_df.append(tmpDf)


# In[114]:


len(individual_features_df)


# In[115]:


all_correlations = {feature.columns[0]: feature.corr()['보증철손'][0] for feature in individual_features_df} #[:50]


# In[116]:


all_correlations = sorted(all_correlations.items(), key=operator.itemgetter(1))
for (key, value) in all_correlations:
    print("{:>15}: {:>15}".format(key, value))


# In[117]:


golden_features_list = [key for key, value in all_correlations if abs(value) >= 0.0001]
print("There is {} strongly correlated values with SalePrice:\n{}".format(len(golden_features_list), golden_features_list))


# In[ ]:





# # 상관성이 높게 나오는 애들에 대한 산점도를 통한 확인이  필요하다

# # Feature to feature relationship

# In[118]:


df_num[golden_features_list].head()


# In[ ]:





# ## correlations

# In[ ]:





# In[119]:



#corr = df_num.drop('보증철손', axis=1).corr() # We already examined 보증철손 correlations
corr = df_num[golden_features_list].corr() # We already examined SalePrice correlations


# In[120]:


corr.head()


# ### heatmap

# In[121]:


plt.figure(figsize=(12, 10))
sns.heatmap(corr[(corr >= 0.3) | (corr <= -0.3)], 
            cmap='viridis', vmax=1.0, vmin=-1.0, linewidths=0.1,
            annot=True, annot_kws={"size": 8}, square=True);


# ## csv로 다운로드하여 분석 한다. 

# In[122]:


corr.to_csv('./correlations.csv', encoding='euc-kr') #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


# In[ ]:




# data_p2 = data[drop_etc]

#num_cols2 = ['보증철손', 'm_보증자구철손','m_보증자속밀도'] #
num_cols2 = ['보증철손', '보증자구철손','보증자속밀도'] #

data_p2 = data[ num_cols2]

# data_p2.head()

data_p2.hist(bins=50, figsize=(15,10)) #, figsize(20,15)
# In[123]:


data_p1 = data[num_cols[:20]]


# In[124]:


data_p1.head()


# In[125]:


# Counter(data.m_작업계상일자)


# In[126]:


# data.head()


# In[ ]:





# In[ ]:





# In[ ]:





# In[127]:


fontprop


# In[128]:


df_num[golden_features_list].head()


# In[129]:


# df_num.head()


# In[130]:


data=df_num


# In[ ]:





# In[131]:


# len1 = len(plot_columns)
# ncols=5

# len1


# In[ ]:





# In[132]:


# var=['폭구분', '실평중량', '냉연코일두께', 'CAST번호']


# In[ ]:





# In[133]:


def gen_kdeplot(data, plot_columns_part, ncols, file_index, savePath):      
    t0 = data.loc[data['Class'] == 0] # Class : 0 인 행만 추출
    t1 = data.loc[data['Class'] == 1] # Class : 1 인 행만 추출
    t2 = data.loc[data['Class'] == 2] # Class : 2 인 행만 추출
    sns.set_style('whitegrid') # 그래프 스타일 지정
    plt.figure()
    
    fig, ax = plt.subplots(1, ncols, figsize = (24, 4)) # 축 지정       
    
    i = 0  
    for feature in plot_columns_part:
        i += 1        
        plt.subplot(1, ncols, i) 
        sns.kdeplot(t0[feature], bw = 0.5, label = "Class = 0", color="r")
        sns.kdeplot(t1[feature], bw = 0.5, label = "Class = 1", color="g")
        sns.kdeplot(t2[feature], bw = 0.5, label = "Class = 2", color="b")
        plt.xlabel(feature, fontsize = 12, fontproperties=fontprop) # 라벨 속성값
        locs, labels = plt.xticks()
        plt.tick_params(axis = 'both', which = 'major', labelsize = 12)
        #plt.rc('axes',titlesize=50)        
    plt.savefig(savePath+"kde_"+str(file_index).zfill(3)+ ".png", dpi=200)
    plt.show();plt.close()    
    return 'ok'  


# In[134]:


# plot_columns_part=['폭구분', '실평중량', '냉연코일두께', 'CAST번호', '25Micro이하분율']

# file_index=1
# gen_kdeplot(data, plot_columns_part, ncols, file_index, savePath)


# In[135]:


savePath="./png/kdeplot/"
mkdir_rm(savePath)

plot_columns=np.sort(golden_features_list).tolist()
#plot_columns=plot_columns[:6]
len1 = len(plot_columns)
ncols=5


# In[136]:


len1


# In[137]:


get_ipython().run_cell_magic('capture', 'cap_out', "for j in range(0, len1, ncols):    \n    #print(j, len1)\n    if (j+ncols)>len1: #전체 칼럼개수보다 크면\n        #print('j, len1-j', j, len1-j)         \n        #print('plot_columns[j:len1-j]', plot_columns[j:len1-j]) \n        plot_columns_part = plot_columns[j:len1]\n        gen_kdeplot(data, plot_columns_part, ncols, j, savePath)\n    else:\n        plot_columns_part = plot_columns[j:j+ncols]\n        gen_kdeplot(data, plot_columns_part, ncols, j, savePath)\n#del cap_out")


# In[138]:


dimage(savePath+"kde_000.png")


# In[139]:


import glob


# In[140]:


savePath="./png/kdeplot_merge/"
mkdir_rm(savePath)

source_dir = r'./png/kdeplot/'
files=glob.glob(source_dir +"*.*")

files=np.sort(files).tolist()
print('len(files) : ', len(files))

nMergeFiles=3
imageMergeHorizontalSrv(files, nMergeFiles, savePath)
png_dir = '/model_data/t/cm/src/python/a_kyungook/a_mag_loss_py/code/png'
targ_dir = png_dir+'/kdeplot_merge'
zipfileNm = png_dir+'/kdeplot_merge.zip'
zip1(targ_dir, zipfileNm)


# In[ ]:





# In[ ]:





# In[ ]:





# ## 아래 부터는 단순 참조용.. 신경쓰지 마시길

# In[ ]:


xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx()  #의도적인 에러 발생


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


X = np.array(data.iloc[:, data.columns != 'Class'])
y = np.array(data.iloc[:, data.columns == 'Class'])
print("Shape of X: {}".format(X.shape))
print("Shape of y: {}".format(y.shape))


# In[ ]:





# In[ ]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)
print("Number transactions X_train dataset: ", X_train.shape)
print("Number transactions y_train dataset: ", y_train.shape)
print("Number transactions X_test dataset: ", X_test.shape)
print("Number transactions y_test dataset: ", y_test.shape)


# In[ ]:


data999 = data.copy()


# In[ ]:





# In[ ]:


data = data_origin.copy()


# In[ ]:


data.columns


# In[ ]:


# 일별 데이터 카운트 
data.groupby("작업계상일자").size()


# In[ ]:



# 일별 유니크 m_재료번호 카운트 및 시각화 
s = data.groupby("작업계상일자")['재료번호'].nunique()


# In[ ]:


#s.index = s.index.dayofweek
s.plot(color='grey', kind='bar', rot=0);
plt.title("Daily nunique_m_재료번호")
plt.tight_layout() 


# In[ ]:


# 일별, 카테고리별 카운트 (피벗팅)
ss = data.groupby(["작업계상일자", "Class"]).size().unstack().dropna(axis=1)
ss


# In[ ]:


cat_cols = [col for col in data.columns if data[col].dtype in ['object']]
cat_cols


# In[ ]:


data[cat_cols].head()


# In[ ]:


data=data.drop(cat_cols,axis=1)


# In[ ]:


cat_cols = [col for col in data.columns if data[col].dtype in ['object']]
cat_cols


# In[ ]:





# In[ ]:





# In[ ]:


num_cols = [col for col in data.columns if data[col].dtype in ['int64','float64']]
len(num_cols)


# In[ ]:


data.head()


# In[ ]:


df_num_cols = data[num_cols[5:20]]


# In[ ]:


df_num_cols.head()


# In[ ]:





# In[ ]:


# https://wikidocs.net/16576
# Scatter Matrix 를 통해 분포 및 변수간 상관관계 시각화 
from pandas.tools.plotting import scatter_matrix

scatter_matrix(df_num_cols, figsize=(30, 30));
plt.tight_layout()

#  상관지수 확인
df_num_cols.corr()


# In[ ]:





# In[ ]:





# In[ ]:





# # 종속변수와 유사한 애들은 삭제한다. 현업확인이 필요하다
# 어제까지 데이터로 학습하고 보증철손을 예측한다.  
# 오늘 재료에 대해 예측을 하는데,  예측하는 시점에 모델에게 X인자를 던져줄수 있어야 한다. 
# 철손등급, 보증철손 이런 값이 없다.
# - '보증철손', 'm_보증자구철손','m_보증자속밀도'

# In[ ]:


drop_cols=['Unnamed: 0','m_작업계상일자','m_년월', 'm_월일', '보증철손', 'm_보증자구철손','m_보증자속밀도'] 
#drop_cols=['m_보증자구철손','m_보증자속밀도'] 

data=data.drop(drop_cols,axis=1)


# In[ ]:





# In[ ]:





# # select features

# In[ ]:


train=data.copy()


# In[ ]:


y=train['Class'].values

train = train.drop('Class', axis=1)

cols = train.columns


# In[ ]:


#Standardization
from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
X_std=sc.fit_transform(train)

df_X_std = pd.DataFrame(X_std, columns=cols)
# df = pd.concat([df_X_std, df_y], axis=1)

df_X_std.head()


# # secect features < ExtraTreesClassifier ---------------------------------------

# In[ ]:


X = df_X_std

from sklearn.ensemble import ExtraTreesClassifier

etc_model = ExtraTreesClassifier()
etc_model.fit(X, y)

# print(etc_model.feature_importances_)
feature_list = pd.concat([pd.Series(X.columns), pd.Series(etc_model.feature_importances_)], axis=1)
feature_list.columns = ['features_name', 'importance']
fl = feature_list.sort_values("importance", ascending =False)[:100]

cols = fl.features_name.tolist()


# In[ ]:


len(cols)


# # shap values 

# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


df_y=data[['Class']]
df_norm = pd.concat([df_y,df_X_std], axis=1)
df_norm.to_csv('mag_loss_norm.csv', encoding='euc-kr')


# In[ ]:


df_norm.head()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


#표준화하지 않는 데이터로 저장 100개 피처만a_mag_loss_py
add_cols =['Class']
cols_f = add_cols+cols
# cols_f
df_no_norm = data[cols_f]
df_no_norm.to_csv('mag_loss_no_norm.csv', encoding='euc-kr')


# In[ ]:


df_no_norm.head()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


train99 = df_X_std[cols]


# In[ ]:


# X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=10, stratify=y)
x_train, x_test, y_train, y_test = train_test_split(train99, y, test_size=0.2, random_state=42, stratify=y)


# In[ ]:




