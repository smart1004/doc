#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# 필요한 변수 추출하기


# In[1]:


import pandas as pd


# In[3]:


# https://statkclee.github.io/author_carpentry_kr/tutorial/reproducible_finance/reproducible_finance.html
# data source: https://www.kaggle.com/yersever/500-person-gender-height-weight-bodymassindex
df = pd.read_csv("./500_Person_Gender_Height_Weight_Index2.csv", encoding="euc-kr")  


# In[8]:


df


# In[ ]:





# In[ ]:





# In[ ]:





# In[27]:


c1 = df[['Height']] #특정 칼럼만 추출


# In[29]:


c1.head()


# In[ ]:





# In[23]:


c2 = df[['Height', 'Weight']] #여러 칼럼을 지정해 추출


# In[24]:


type(c2)


# In[25]:


c2.head()


# In[30]:


df.head()


# In[43]:


# 특정 칼럼을 제외하고 추출하기 
df2=df[df.columns.difference(['Index', 'Index_kr'])]
print(df2.head())
print('')
print('df2.columns:', df2.columns)


# In[ ]:





# In[44]:


# 특정 칼럼을 제외하고 추출하기 
df2=df.drop(columns = ['Index', 'Index_kr']) 
print(df2.head())
print('')
print('df2.columns:', df2.columns)


# In[ ]:




