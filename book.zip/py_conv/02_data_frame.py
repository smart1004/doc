#!/usr/bin/env python
# coding: utf-8

# In[ ]:




"""


"""
# In[2]:


import pandas as pd


# In[3]:


# data source: 광고정보센터(https://www.adic.or.kr/)
df = pd.read_csv("./2020_06_광고주광고비.csv")  


# In[4]:


df.head()


# In[5]:


df.head(10)  #앞에서 10개 행만 출력 


# In[6]:


df.tail() # 데이터의 뒷부분 출력


# In[7]:


df.tail(10) # 데이터의 뒷부분 10개 행 출력


# In[10]:


# 몇개의 행, 열로 구성된 데이터인가?
print(df.shape)    # (500, 6)  : 500행, 6열 


# In[ ]:





# In[16]:


# 데이터에 대한 전반적인 정보를 나타냅니다. 
# df를 구성하는 행과 열의 크기, 컬럼명, 컬럼을 구성하는 값의 자료형 등을 출력해줍니다.
# RangeIndex: 500 entries <-- 500개 데이터가 있다
# Data columns (total 6 columns):  <-- 6 columns

# 각 칼럼의 Non-Null Count, Dtype 을 출력. Dtype은  datatype을 말한다. 정수형(int64), 실수형(float64), 
# 회사명 칼럼(변수)은  500 non-null <-- 500개의 non-null 값을 가진다. 즉, 회사명은 500개 모두 non-null이다.
#    null이란 빈값(엑셀의 경우, 비어있는 셀)을 말한다. 아무런 값이 없는 것=관측된 값이 없는 것을 의미함 
#    회사명 칼럼은 object형(문자형)이다
df.info()


# In[11]:


df.describe() #숫자형 칼럼에 대한 요약 통계량 산출
# 간단한 통계 정보를 보여줍니다. 컬럼별로 데이터의 개수(count), 데이터의 평균값(mean), 표준 편차(std), 
# 최솟값(min), 4분위수(25%, 50%, 75%), 그리고 최댓값(max)들의 정보를 알 수 있습니다.
# 4분위수(25%, 50%, 75%)
# 25%: 25% 지점(4분의 1)에 위치하는 값
# 50%: 중앙값(median)
# 75%: 75% 지점(4분의 3)에 위치하는 값


# In[14]:


# 이렇게 숫자가 지수표현식으로 나와서 불편할 때가 있습니다
pd.options.display.float_format = '{:.3f}'.format

# 다시 원래대로 옵션을 변경하고 싶을 때는 아래 명령어를 사용하면 됩니다
# pd.reset_option('display.float_format') 


# In[ ]:





# In[15]:


df.describe() #소수점 세자리까지 출력


# In[23]:


df.describe().T # 칼럼이 대량인 경우
#.T 속성은 DataFrame 에서 index 와 column 을 바꾼 형태의 DataFrame 입니다. 


# In[18]:


df[df.duplicated(["회사명"])]


# In[ ]:





# In[24]:


df.head()


# In[25]:


df.rename(columns={"TV" : "텔레비전"}, inplace=True) # 칼럼명 바꾸기


# In[26]:


df.head()


# In[27]:


df.rename(columns={"라디오":"Radio", "텔레비전":"TV"}, inplace=True) # 여러개 칼럼명 바꾸기


# In[29]:


df.head()


# In[ ]:




