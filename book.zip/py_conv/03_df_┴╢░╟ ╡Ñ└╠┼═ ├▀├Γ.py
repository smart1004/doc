#!/usr/bin/env python
# coding: utf-8

# In[ ]:


### 조건에 맞는 데이터만 추출


# In[ ]:


#https://statkclee.github.io/author_carpentry_kr/tutorial/reproducible_finance/reproducible_finance.html


# In[1]:


import pandas as pd


# In[3]:


# https://statkclee.github.io/author_carpentry_kr/tutorial/reproducible_finance/reproducible_finance.html
# data source: https://www.kaggle.com/yersever/500-person-gender-height-weight-bodymassindex
df = pd.read_csv("./500_Person_Gender_Height_Weight_Index.csv")  


# In[4]:


df.head()

Gender : Male / Female
Height : Number (cm)
Weight : Number (Kg)
Index :
0 : Extremely Weak
1 : Weak
2 : Normal
3 : Overweight
4 : Obesity
5 : Extreme Obesity
#c("0극저체중", "1저체중", "2정상", "3과체중", "4비만", "5고도비만")),
# In[7]:


equiv = {0:"0극저체중", 1:"1저체중", 2:"2정상", 3:"3과체중", 4:"4비만", 5:"5고도비만"}


# In[8]:


df["Index_kr"] = df["Index"].map(equiv)


# In[9]:


df.head()


# ### 조건에 맞는 데이터만 추출

# In[5]:


df[df.Gender=="Male"] # Male만 추출


# In[6]:


df[df.Gender=="Female"] # Female 만 추출


# In[10]:


df[df.Height > 180]


# In[11]:


df[df.Height >= 180] # > = 를 


# In[18]:





# In[20]:


df[ (df.Height >= 170) & (df.Height <= 180) ] # 170이상 ~ 180이하
# & : and , 여러 조건을 동시에 만족하는 행을 선택


# In[ ]:





# In[21]:


df['Index_kr'].value_counts() #특정 컬럼 내에 존재하는 각각의 값의 개수를 알 수 있습니다.


# In[22]:


df['Index_kr'].value_counts(normalize=True)
# normalize 옵션을 사용하면, 각 범주별로 몇 %를 차지하는지 알수 있다


# In[26]:


condition_비만 = df['Index_kr'].str.contains("4비만|5고도비만")


# In[28]:


condition_비만[:5]


# In[27]:


df[condition_비만]


# In[29]:


df[ df['Index_kr'].str.contains("4비만|5고도비만") ] 
# 한줄로 표현  | 는 or를 의미, 4비만 또는 5고도비만을 포함하는 행을 찾는다


# In[35]:


df_filter_저체중 = df[ df['Index_kr'].str.contains("저체중") ]  # "저체중"을 포함하는 문자열이 존재하는 행 추출
df_filter_저체중['Index_kr'].value_counts()


# In[ ]:





# In[30]:


df['Index_kr'].value_counts()


# In[32]:


df_filter1 = df[ (df.Index_kr =="0극저체중") | (df.Index_kr =="5고도비만") ] 
# or 여러 조건 중에 하나라도 만족하는 행 추출하기


# In[34]:


df_filter1['Index_kr'].value_counts()


# In[36]:


df.head()


# In[39]:


df.to_csv('500_Person_Gender_Height_Weight_Index2.csv', encoding='euc-kr', index=False)


# In[ ]:




