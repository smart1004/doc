#!/usr/bin/env python
# coding: utf-8

# In[ ]:





# In[ ]:


# 아래가 진짜다
#https://codedragon.tistory.com/7748


# In[ ]:





# In[29]:


import matplotlib as mpl

#font 설정 파일 위치 출력
mpl.matplotlib_fname()

# matplotlibrc 파일의 주석을 풀어주고, 글꼴을 세팅한다.
font.family         : D2Coding
# In[ ]:





# In[ ]:





# In[ ]:





# In[1]:


import pandas as pd


# In[2]:


# data source: 광고정보센터(https://www.adic.or.kr/)
df = pd.read_csv("./2020_06_광고주광고비.csv")  


# In[3]:


df.head()


# In[ ]:





# In[ ]:





# ### 칼럼을 삭제 후에 추가 해보자  
#   

# In[4]:


df = df.drop(columns = ['전체']) 


# In[5]:


df.head()


# In[6]:


df['전체1'] = df.TV+df.라디오+df.신문+df.잡지


# In[7]:


df.head()


# In[8]:


total = df['TV'].sum() #열의 총합 구해보자
print ("TV column sum:",total)


# In[ ]:





# In[9]:


# 광고비_평균을 구해, 칼럼을 추가
df['광고비_평균'] = (df.TV+df.라디오+df.신문+df.잡지)/4


# In[10]:


df.head()


# In[ ]:





# In[ ]:





# In[ ]:





# In[11]:


import matplotlib.pyplot as plt
import seaborn as sns


# In[17]:


print(df['전체1'].describe())
plt.figure(figsize=(9, 8))
sns.distplot(df['전체1']/1000000, color='g', bins=10, hist_kws={'alpha': 0.4});


# In[ ]:




