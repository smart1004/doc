from konlpy.tag import Twitter
from collections import Counter
from operator import eq
import math

# ================================ get_tags =======================================
# =================================================================================
# OBJECTIVES: 1. calculate the list of noun and count
#             2. calculate the number of each unique word
#             3. calculate the number of count of most frequent word
def get_tags(text, ntags=50):
    spliter = Twitter()
    Num_unique_words = 0            # THE NUMBER OF UNIQUE WORD
    Num_most_frequent = 0           # THE NUMBER OF THE MOST FREQUENT WORD IN A DOCUMENT
    nouns = spliter.nouns(text)     # nouns 함수를 통해서 text에서 명사만 분리/추출

    count = Counter(nouns)          # count : entire number of words in text file
                                    # Counter객체를 생성하고 참조변수 nouns할당
    return_list = []                # 명사 빈도수 저장할 변수

    for n, c in count.most_common(ntags):
        temp = {'tag': n, 'count': c}
        return_list.append(temp)
        Num_unique_words = Num_unique_words+1
        if Num_unique_words == 1:
            Num_most_frequent = c

    # most_common 메소드는 정수를 입력받아 객체 안의 명사중 빈도수
    # 큰 명사부터 순서대로 입력받은 정수 갯수만큼 저장되어있는 객체 반환
    # 명사와 사용된 갯수를 return_list에 저장합니다.

    return Num_unique_words, Num_most_frequent, return_list


"""
    # print((tag1[0])['tag'])    --> 육아휴직
    # print((tag1[0])['count'])  --> 38
    # input() <-- input the request
    #
    for n in tag1:
        noun = n['tag']
        count = n['count']
        #if eq(((tag1[n])['tag']), '육아휴직'):
        if eq(noun, request):
            print('Hi same')
"""
# ================================ Load_GET_TFIDF =================================
# =================================================================================
# OBJECTIVES: 1. load all source corpus
#             2. using 'get_tags' for calculating TF-IDF of requested word
#             3. Finally, return tf-idf('requested word', 'docID', 'entirecorpus') for
def Load_GET_TFIDF(request):
    # Initialize the request string of tfidf calculation objective.
    REQUEST = request
    Num_of_docs = 10
    # load origin files and create result file
    news1 = "/Users/dohyun/PycharmProjects/news/news1.txt"
    news1_result = "/Users/dohyun/PycharmProjects/news/news1_result.txt"
    news2 = "/Users/dohyun/PycharmProjects/news/news2.txt"
    news2_result = "/Users/dohyun/PycharmProjects/news/news2_result.txt"
    news3 = "/Users/dohyun/PycharmProjects/news/news3.txt"
    news3_result = "/Users/dohyun/PycharmProjects/news/news3_result.txt"
    news4 = "/Users/dohyun/PycharmProjects/news/news4.txt"
    news4_result = "/Users/dohyun/PycharmProjects/news/news4_result.txt"
    news5 = "/Users/dohyun/PycharmProjects/news/news5.txt"
    news5_result = "/Users/dohyun/PycharmProjects/news/news5_result.txt"
    news6 = "/Users/dohyun/PycharmProjects/news/news6.txt"
    news6_result = "/Users/dohyun/PycharmProjects/news/news6_result.txt"
    news7 = "/Users/dohyun/PycharmProjects/news/news7.txt"
    news7_result = "/Users/dohyun/PycharmProjects/news/news7_result.txt"
    news8 = "/Users/dohyun/PycharmProjects/news/news8.txt"
    news8_result = "/Users/dohyun/PycharmProjects/news/news8_result.txt"
    news9 = "/Users/dohyun/PycharmProjects/news/news9.txt"
    news9_result = "/Users/dohyun/PycharmProjects/news/news9_result.txt"
    news10 = "/Users/dohyun/PycharmProjects/news/news10.txt"
    news10_result = "/Users/dohyun/PycharmProjects/news/news10_result.txt"

    noun_count = 500
    # 최대 많은 빈도수 부터 max 500개 명사 추출

    # open news
    open_news1 = open(news1, 'r', -1, "utf-8")
    open_news2 = open(news2, 'r', -1, "utf-8")
    open_news3 = open(news3, 'r', -1, "utf-8")
    open_news4 = open(news4, 'r', -1, "utf-8")
    open_news5 = open(news5, 'r', -1, "utf-8")
    open_news6 = open(news6, 'r', -1, "utf-8")
    open_news7 = open(news7, 'r', -1, "utf-8")
    open_news8 = open(news8, 'r', -1, "utf-8")
    open_news9 = open(news9, 'r', -1, "utf-8")
    open_news10 = open(news10, 'r', -1, "utf-8")

    # read news1
    text_news1 = open_news1.read()
    text_news2 = open_news2.read()
    text_news3 = open_news3.read()
    text_news4 = open_news4.read()
    text_news5 = open_news5.read()
    text_news6 = open_news6.read()
    text_news7 = open_news7.read()
    text_news8 = open_news8.read()
    text_news9 = open_news9.read()
    text_news10 = open_news10.read()

    # List of text_news
    Num_unique_words1, Num_most_frequent1, tag1 = get_tags(text_news1, noun_count)
    Num_unique_words2, Num_most_frequent2, tag2 = get_tags(text_news2, noun_count)
    Num_unique_words3, Num_most_frequent3, tag3 = get_tags(text_news3, noun_count)
    Num_unique_words4, Num_most_frequent4, tag4 = get_tags(text_news4, noun_count)
    Num_unique_words5, Num_most_frequent5, tag5 = get_tags(text_news5, noun_count)
    Num_unique_words6, Num_most_frequent6, tag6 = get_tags(text_news6, noun_count)
    Num_unique_words7, Num_most_frequent7, tag7 = get_tags(text_news7, noun_count)
    Num_unique_words8, Num_most_frequent8, tag8 = get_tags(text_news8, noun_count)
    Num_unique_words9, Num_most_frequent9, tag9 = get_tags(text_news9, noun_count)
    Num_unique_words10, Num_most_frequent10, tag10 = get_tags(text_news10, noun_count)

    # read file closed
    open_news1.close()
    open_news2.close()
    open_news3.close()
    open_news4.close()
    open_news5.close()
    open_news6.close()
    open_news7.close()
    open_news8.close()
    open_news9.close()
    open_news10.close()

    # open files for writing word and count info using tag (73~82 line) #
    out_news1 = open(news1_result, 'w', -1, "utf-8")
    out_news2 = open(news2_result, 'w', -1, "utf-8")
    out_news3 = open(news3_result, 'w', -1, "utf-8")
    out_news4 = open(news4_result, 'w', -1, "utf-8")
    out_news5 = open(news5_result, 'w', -1, "utf-8")
    out_news6 = open(news6_result, 'w', -1, "utf-8")
    out_news7 = open(news7_result, 'w', -1, "utf-8")
    out_news8 = open(news8_result, 'w', -1, "utf-8")
    out_news9 = open(news9_result, 'w', -1, "utf-8")
    out_news10 = open(news10_result, 'w', -1, "utf-8")

    # 결과로 쓰일 count.txt 열기
    for tag in tag1:
        noun = tag['tag']
        count = tag['count']
        out_news1.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news1.close()

    for tag in tag2:
        noun = tag['tag']
        count = tag['count']
        out_news2.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news2.close()

    for tag in tag3:
        noun = tag['tag']
        count = tag['count']
        out_news3.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news3.close()

    for tag in tag4:
        noun = tag['tag']
        count = tag['count']
        out_news4.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news4.close()

    for tag in tag5:
        noun = tag['tag']
        count = tag['count']
        out_news5.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news5.close()

    for tag in tag6:
        noun = tag['tag']
        count = tag['count']
        out_news6.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news6.close()

    for tag in tag7:
        noun = tag['tag']
        count = tag['count']
        out_news7.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news7.close()

    for tag in tag8:
        noun = tag['tag']
        count = tag['count']
        out_news8.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news8.close()

    for tag in tag9:
        noun = tag['tag']
        count = tag['count']
        out_news9.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news9.close()

    for tag in tag10:
        noun = tag['tag']
        count = tag['count']
        out_news10.write('{} {}\n'.format(noun, count))
    # 결과 저장
    out_news10.close()

    # get list of words of each news file
    # Num_unique_words# : Number of total words in document
    # Num_most_frequent# : Number of words which is the most frequent

    # print(Num_unique_words1) : 250 ( total number of unique words in a document)
    # print(Num_most_frequent1) : 38 ( the maximum number of words in a document )

    # >>> TF calculation
    Num_unique_words1, Num_most_frequent1, tag1 = get_tags(text_news1, noun_count)
    TF1 = TF(REQUEST, Num_most_frequent1, tag1)
    Num_unique_words2, Num_most_frequent2, tag2 = get_tags(text_news2, noun_count)
    TF2 = TF(REQUEST, Num_most_frequent2, tag2)
    Num_unique_words3, Num_most_frequent3, tag3 = get_tags(text_news3, noun_count)
    TF3 = TF(REQUEST, Num_most_frequent3, tag3)
    Num_unique_words4, Num_most_frequent4, tag4 = get_tags(text_news4, noun_count)
    TF4 = TF(REQUEST, Num_most_frequent4, tag4)
    Num_unique_words5, Num_most_frequent5, tag5 = get_tags(text_news5, noun_count)
    TF5 = TF(REQUEST, Num_most_frequent5, tag5)
    Num_unique_words6, Num_most_frequent6, tag6 = get_tags(text_news6, noun_count)
    TF6 = TF(REQUEST, Num_most_frequent6, tag6)
    Num_unique_words7, Num_most_frequent7, tag7 = get_tags(text_news7, noun_count)
    TF7 = TF(REQUEST, Num_most_frequent7, tag7)
    Num_unique_words8, Num_most_frequent8, tag8 = get_tags(text_news8, noun_count)
    TF8 = TF(REQUEST, Num_most_frequent8, tag8)
    Num_unique_words9, Num_most_frequent9, tag9 = get_tags(text_news9, noun_count)
    TF9 = TF(REQUEST, Num_most_frequent9, tag9)
    Num_unique_words10, Num_most_frequent10, tag10 = get_tags(text_news10, noun_count)
    TF10 = TF(REQUEST, Num_most_frequent10, tag10)

    # IDF calculation
    IDF_ = IDF(Num_of_docs, REQUEST, tag1, tag2, tag3, tag4, tag5,
               tag6, tag7, tag8, tag9, tag10)

    List_TFIDF = [TF1*IDF_, TF2*IDF_, TF3*IDF_, TF4*IDF_, TF5*IDF_,
                  TF6*IDF_, TF7*IDF_, TF8*IDF_, TF9*IDF_, TF10*IDF_]

    # Recommend the most related document among corpus
    # based on Tf-idf.
    Recommendation(List_TFIDF)
# ================================ TF calculation =================================
# =================================================================================
# ***** TF calculation *****
# ARGS : request   : Request string
#        most_freq : The number of words which is the most frequent in the document (document 'tag')
#        tag       : Target document
def TF(request, most_freq, tag):
    # tf calculation:
    # tf(t, d) = 0.5 + 0.5*f(t,d)/most_freq(d)
    return 0.5 + 0.5*Howmanywords(request, tag)/most_freq

# =============================== IDF calculation =================================
# =================================================================================
# OBJECTIVES: return IDF value which represents the importance of string in range of
#             entire set of documents

# ARGS : Num_of_docs       : Total number of documents in corpus
#        request           : Request string
#        tag1, ..., tag10  : Set of documents
def IDF(Num_of_docs, request, tag1, tag2, tag3, tag4, tag5,
        tag6, tag7, tag8, tag9, tag10):
    # <idf calculation>
    # idf(t, D) = log(Num_of_docs/1+num_of_documents_including_request)
    List_tags = [tag1, tag2, tag3, tag4, tag5,
                 tag6, tag7, tag8, tag9, tag10]

    # Number of documents which includes the 'request'
    Num_of_Docs_includes_request = 0

    # count how many documents which includes the 'request'
    for n in List_tags:
        for i in n:
            noun = i['tag']
            if eq(noun, request):
                Num_of_Docs_includes_request = Num_of_Docs_includes_request + 1
                continue

    # finally get the total number of num_of_documents_including_request
    # return the IDF value
    return math.log10(Num_of_docs/1+Num_of_Docs_includes_request)

# ================================ Howmanywords ===================================
# =================================================================================

# ***** Howmanywords definition *****
# OBJECTIVES: return how many the 'request' is exists in document.

# ARGS : request : represents the request
#        tag
def Howmanywords(request, tag):
    noWords = 0
    for n in tag:
        noun = n['tag']
        count = n['count']
        if eq(noun, request):
            return count
    # if there are not any 'request' in the document, then return 0
    return noWords

# ========================== Recommend document =============================
# =================================================================================
# OBJECTIVES: Recommend a document based on calculated List_TFIDF
# ARGS :
def Recommendation(List_TFIDF):
    Maxidx = List_TFIDF.index(max(List_TFIDF))
    print("The most relevant document of requested string DOCUMENT %d \n" %(Maxidx+1))

def main():

    while 1:
        print("Enter a request ('quit' for terminating the program): ")
        request = input()
        if request == 'quit' or request == 'QUIT' or request == 'Quit':
            print("Terminating the program\n")
            return
        else:
            Load_GET_TFIDF(request)

if __name__ == '__main__':
    main()