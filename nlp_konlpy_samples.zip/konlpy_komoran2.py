from konlpy.tag import Komoran
komoran = Komoran(userdic='lib/dic.txt') 
# komoran = Komoran(userdic='lib/dic2.txt')
print(komoran.morphs('우왕 코모란도 오픈소스가 되었어요'))
print(komoran.nouns('오픈소스에 관심 많은 멋진 개발자님들!'))
print(komoran.pos('혹시 바람과 함께 사라지다 봤어?'))
