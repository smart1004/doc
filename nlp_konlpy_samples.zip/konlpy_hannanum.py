# -*- coding: utf-8 -*- 
from konlpy.tag import Hannanum
hannanum = Hannanum()
print(hannanum.analyze('롯데마트의 흑마늘 양념 치킨이 논란이 되고 있다.'))
print(hannanum.morphs('롯데마트의 흑마늘 양념 치킨이 논란이 되고 있다.'))
print(hannanum.nouns('다람쥐 헌 쳇바퀴에 타고파'))
print(hannanum.pos('웃으면 더 행복합니다!'))
