from newspaper import Article
# pip install newspaper3k
url1 = 'http://v.media.daum.net/v/20170604205121164' #크롤링할 url 주소 입력
url2 = 'http://news.nate.com/view/20180810n20003?mid=n0412'
url3 = 'https://www.nytimes.com/2018/09/03/opinion/ukraine-corruption-heart-stents-procurement.html?action=click&module=Opinion&pgtype=Homepage'
#a = Article(url3, language='ko') #언어가 한국어이므로 language='ko'로 설정
a = Article(url3, language='en') #언어가 한국어이므로 language='ko'로 설정
a.download()
a.parse()
print(a.title) #기사 제목 가져오기
print(a.text[:]) #기사 내용 가져오기(150자)
#print(a.text[:150]) #기사 내용 가져오기(150자)
