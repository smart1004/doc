import sys
from bs4 import BeautifulSoup
from urllib.request import urlopen

original_stdout = sys.stdout
file = open('file_180904_1.txt', 'w', encoding='UTF-8')
sys.stdout = file

url = urlopen('https://www.boannews.com/media/view.asp?idx=57628&skind=O')
soup = BeautifulSoup(url, "lxml")

title = soup.find_all("div",{"id":"news_title02"})
contents = soup.find_all("div",{"id":"news_content"})

print(title)
print(contents)

sys.stdout = original_stdout
file.close()
