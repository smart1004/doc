import numpy as np
import tensorflow as tf
from tensorflow.contrib import rnn
 
sentence = ("if you want to build a ship, don't drum up people together to "
            "collect wood and don't assign them tasks and work, but rather "
            "teach them to long for the endless immensity of the sea.")
 
char_set = list(set(sentence))
print(char_set)
 
# 알파벳을 Key로 하고 인덱스를 Value로 하는 딕셔너리를 생성한다
char_dic = {w:i for i,w in enumerate(char_set)}
print(char_dic)
print("len(char_set): ", len(char_set));
hidden_size = len(char_set) # cell output size
num_classes = len(char_set) # classification number
sequence_length = 10        # length of one sequence
 
dataX = []   # 입력 시퀀스들을 저장하기 위한 배열
dataY = []   # 출력 시퀀스들을 저장하기 위한 배열
for i in range(0, len(sentence) - sequence_length):
    x_str = sentence[i   :  i+sequence_length]   # 시퀀스길이만큼을 문자열
    y_str = sentence[i+1 :  i+sequence_length+1] # 입력보다 1칸 오른쪽에서 시작하는 시퀀스길이만큼의 문자열
    print(i, ": ", x_str, '->', y_str, end='')
    
    x = [char_dic[c] for c in x_str]
    y = [char_dic[c] for c in y_str]
    print(" ====> ", x, '->', y)
    
    dataX.append(x)
    dataY.append(y)
 
 
batch_size = len(dataX)
print("batch_size: ", batch_size)

print("sequence_length: ", sequence_length)

X = tf.placeholder(tf.int32, [None, sequence_length])
Y = tf.placeholder(tf.int32, [None, sequence_length])

print("X: ", X)
print("num_classes: ", num_classes)
X_one_hot = tf.one_hot(X, num_classes)
print("X_one_hot: ", X_one_hot)
 
def lstm_cell():
    cell = rnn.BasicLSTMCell(num_units=hidden_size, forget_bias=0.8, state_is_tuple=True)
    return cell
 
# Stacked RNNs (3 levels)
multi_cells = rnn.MultiRNNCell([lstm_cell() for _ in range(3)], state_is_tuple=True)
 
# RNN Cell 
hypothesis, _states = tf.nn.dynamic_rnn(multi_cells, X_one_hot, dtype=tf.float32)
print("hypothesis: ", hypothesis)
 
# hidden size: output size of each RNN(LSTM) cell
print("hidden_size: ", hidden_size)
 
X_for_fc = tf.reshape(hypothesis, [-1, hidden_size])
# Fully Connected Layer를 생성(활성화함수는 미사용)
# FC(Fully Connected)의 출력은 전체분류개수
hypothesis = tf.contrib.layers.fully_connected(inputs=X_for_fc, num_outputs=num_classes, activation_fn=None)
print("hypothesis: ", hypothesis)
  
# sequence_loss를 측정하기위한 형상변환
print("batch_size: ", batch_size)
print("sequence_length: ", sequence_length)
print("num_classes: ", num_classes)
hypothesis = tf.reshape(hypothesis, [batch_size, sequence_length, num_classes])
print("hypothesis: ", hypothesis)
  
# sequence loss를 구할 때 모든 sequence의 가중치를 동일하게 1로 설정한다.
# 예를들어 최근 것에 가중치를 더 줄 수도 있음
weights = tf.ones([batch_size, sequence_length])
print("weights: ", weights)
  
# sequence loss를 구한다
sequence_loss = tf.contrib.seq2seq.sequence_loss(logits=hypothesis, targets=Y, weights=weights)
cost = tf.reduce_mean(sequence_loss)
train = tf.train.AdamOptimizer(0.1).minimize(cost)
  
sess = tf.Session()
sess.run(tf.global_variables_initializer())
 
 
for epoch in range(200):
    _, c, results = sess.run([train, cost, hypothesis], feed_dict={X: dataX, Y: dataY})
    print("cost.shape: ", c.shape) # 스칼라 값
    print("results.shape: ", results.shape)
    for i, result in enumerate(results):
        if i is 0:
            print("result.shape: ", result.shape)
        indexs = np.argmax(result, axis=1)
        if i is 0:
            print("indexs.shape: ", indexs.shape) # sequence_length와 같다
        print(epoch, i, ''.join([char_set[t] for t in indexs]), cost)
 
results = sess.run(hypothesis, feed_dict={X: dataX})
print("results.shape: ", results.shape)
for i, result in enumerate(results):
    if i is 0:
        print("result.shape: ", result.shape)
        print(char_set[dataX[0][0]], end='') # 입력의 첫번째 글자를 출력한다(개행하지 않음)
    indexs = np.argmax(result, axis=1)
    if i is 0:
        # 첫줄은 sequence_length만큼 출력한다
        print(''.join([char_set[t] for t in indexs]), end='') # 개행하지 않음
    else:
        # 두번째줄부터는 마지막 1글자만 출력한다.(sequence_length만큼 붙이면 마지막 1글자를 제외한 중복이다)
        print(char_set[indexs[-1]], end='') # 개행하지 않음
