import feedparser # crawl rss
from newspaper import Article # crawl newapaper
from konlpy.tag import Komoran # parse title
from konlpy.tag import Twitter # tf-idf
from collections import Counter
from operator import eq
import math # calcurate
import numpy as np
komoran = Komoran()

urls = (
    "https://rss.joins.com/sonagi/joins_sonagi_sports_list.xml" #중앙일보 : 많이본뉴스 스포츠
    , "https://rss.joins.com/sonagi/joins_sonagi_star_list.xml" #중앙일보 : 많이본뉴스 연예
    , "https://rss.joins.com/sonagi/joins_sonagi_life_list.xml" #중앙일보 : 많이본뉴스 사회
    , None
)

#=========================
# rss 에서 기사제목과 기사링크를 추출하는 함수
#=========================
def crawl_rss(urls):
    n = []
    for url in urls:
        print("[crawl rss] ",url)
        d = feedparser.parse(url)
        for e in d.entries:
            n.append({'title':e.title, 'link':e.link})
    return n

#=========================
# url 에서 기사제목과 기사본문을 추출하는 함수
#=========================
def crawl_article(url, language='ko'):
    print("[crawl article] ",url)
    a = Article(url, language=language) #언어가 한국어이므로 language='ko'로 설정
    a.download()
    a.parse()
    return a.title, a.text

# ================================ get_tags =======================================
# =================================================================================
# OBJECTIVES: 1. calculate the list of noun and count
#             2. calculate the number of each unique word
#             3. calculate the number of count of most frequent word
def get_tags(text, ntags=50):
    spliter = Twitter()
    Num_unique_words = 0            # THE NUMBER OF UNIQUE WORD
    Num_most_frequent = 0           # THE NUMBER OF THE MOST FREQUENT WORD IN A DOCUMENT
    nouns = spliter.nouns(text)     # nouns 함수를 통해서 text에서 명사만 분리/추출

    count = Counter(nouns)          # count : entire number of words in text file
                                    # Counter객체를 생성하고 참조변수 nouns할당
    return_list = []                # 명사 빈도수 저장할 변수

    for n, c in count.most_common(ntags):
        temp = {'tag': n, 'count': c}
        return_list.append(temp)
        Num_unique_words = Num_unique_words+1
        if Num_unique_words == 1:
            Num_most_frequent = c

    # most_common 메소드는 정수를 입력받아 객체 안의 명사중 빈도수
    # 큰 명사부터 순서대로 입력받은 정수 갯수만큼 저장되어있는 객체 반환
    # 명사와 사용된 갯수를 return_list에 저장합니다.

    return Num_unique_words, Num_most_frequent, return_list


# ================================ TF calculation =================================
# =================================================================================
# ***** TF calculation *****
# ARGS : request   : Request string
#        most_freq : The number of words which is the most frequent in the document (document 'tag')
#        tag       : Target document
def TF(request, most_freq, tag):
    # tf calculation:
    # tf(t, d) = 0.5 + 0.5*f(t,d)/most_freq(d)
    return 0.5 + 0.5*Howmanywords(request, tag)/most_freq

# =============================== IDF calculation =================================
# =================================================================================
# OBJECTIVES: return IDF value which represents the importance of string in range of
#             entire set of documents

# ARGS : Num_of_docs       : Total number of documents in corpus
#        request           : Request string
#        List_tags  : Set of documents
def IDF(request, List_tags):
    Num_of_docs = len(List_tags)
    # <idf calculation>
    # idf(t, D) = log(Num_of_docs/1+num_of_documents_including_request)
    
    # Number of documents which includes the 'request'
    Num_of_Docs_includes_request = 0

    # count how many documents which includes the 'request'
    for n in List_tags:
        for i in n:
            noun = i['tag']
            if eq(noun, request):
                Num_of_Docs_includes_request = Num_of_Docs_includes_request + 1
                continue

    # finally get the total number of num_of_documents_including_request
    # return the IDF value
    return math.log10(Num_of_docs/(0.001+Num_of_Docs_includes_request))

# ================================ Howmanywords ===================================
# =================================================================================

# ***** Howmanywords definition *****
# OBJECTIVES: return how many the 'request' is exists in document.
# ARGS : request : represents the request
#        tag
def Howmanywords(request, tag):
    noWords = 0
    for n in tag:
        noun = n['tag']
        count = n['count']
        if eq(noun, request):
            return count
    # if there are not any 'request' in the document, then return 0
    return noWords


#=========================
# Cosine Similarity
#=========================
def cos_sim(a, b):
    dot_product = np.dot(a, b)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    return dot_product / (norm_a * norm_b)


#=========================
# Main
#=========================
def main():
    # 1. rss에서 기사제목과 링크 목록을 가져온다.
    article_list = crawl_rss(urls) #[:10]
        
    # 2. 기사 링크에서 기사본문을 가져옴
    for atricle in article_list:
        _, text = crawl_article(atricle['link'])
        atricle['text'] = text
    
    # 3. 기사 제목 파싱
    print('[parse title]')
    noun_title = [komoran.nouns(a['title']) for a in article_list]
    
    # 4. 기사 본문 파싱
    print('[parse text]')
    noun_text = []
    for a in article_list:
        num_unique_words, num_most_frequent, tag = get_tags(a['text'])
        noun_text.append({'num_unique_words':num_unique_words, 'num_most_frequent':num_most_frequent, 'tags':tag})
        
    # 5. 기사 제목 TF-IDF 계산
    tf_idf_title = []
    tf_idf_mean = []
    tag_list = [a['tags'] for a in noun_text]
    for i, nouns in enumerate(noun_title):
        tfs = [TF(req, noun_text[i]['num_most_frequent'], noun_text[i]['tags']) for req in nouns]
        idfs = [IDF(req, tag_list) for req in nouns]
        _tfidf = [tfs[j] * idfs[j] for j,n in enumerate(nouns)]
        tf_idf_title.append(_tfidf)
        tf_idf_mean.append(np.mean(_tfidf))
        
    print("===[TF-IDF values]==========================================================================================")
    print(tf_idf_title)
    
    print("===[TF-IDF mean]==========================================================================================")
    for i,e in enumerate(tf_idf_mean):
         print("TF-IDF : ",e," , title : ",article_list[i]['title'])
        
    # 6. 제목 tf-idf top5와 문서안의 tf top5의 단어사전 만듬
    wordset = set([])
    for n, nounlist in enumerate(noun_title):
        for w in np.argsort(np.array(tf_idf_title[n]))[:5] :
            wordset.add(nounlist[w])
    
    for doc in noun_text:
        for tags in doc['tags'][:5]:
            wordset.add(tags['tag'])
            
    word_dict = { t : (i+1) for i,t in enumerate(wordset) }
    print("===[Word dictionary]==========================================================================================")
    print(word_dict)
    
    # 7. 제목 tf-idf top5와 문서안의 tf top5를 벡터로 표시
    title_vec = []
    for n, nounlist in enumerate(noun_title):
        _tmp = []
        for w in np.argsort(np.array(tf_idf_title[n]))[:5] :
            _tmp.append(word_dict[nounlist[w]])
        while len(_tmp) < 5:
            _tmp.append(0)
        title_vec.append(_tmp)
    print("===[Word vector : title]==========================================================================================")
    print(title_vec)
    
    text_vec = []
    for doc in noun_text:
        _tmp = []
        for tags in doc['tags'][:5]:
            _tmp.append(word_dict[tags['tag']])
        text_vec.append(_tmp)
    print("===[Word vector : text]==========================================================================================")
    print(text_vec)
    
    # 8. Cosine similarity 계산
    cosine_similarities = [cos_sim(t,text_vec[i]) for i,t in enumerate(title_vec)]
    print("===[cosine similarities]==========================================================================================")
    print(cosine_similarities)
    
    
    # 9. TF-IDF 평균이 제일 작은거 큰거 출력
    idx_tfidf = np.argsort(np.array(tf_idf_mean))
    
    print("\n===[Top3 : Largest TF-IDF mean]==========================================================================================")
    for n,i in enumerate(np.flipud(idx_tfidf)[:3]) : 
        print("(",n+1,") : ",tf_idf_mean[i]," , title : ",article_list[i]['title'])
        print("\t link : ",article_list[i]['link'])
    
    print("===[Top3 : Smallest TF-IDF mean]==========================================================================================")
    for n,i in enumerate(idx_tfidf[:3]) :
        print("(",n+1,") : ",tf_idf_mean[i]," , title : ",article_list[i]['title'])
        print("\t link : ",article_list[i]['link'])
        
    # 10. Cosine-Similarity 제일 작은거 큰거 출력
    idx_tfidf = np.argsort(np.array(cosine_similarities))
    
    print("\n===[Top3 : Largest Cosine Similarity]==========================================================================================")
    for n,i in enumerate(np.flipud(idx_tfidf)[:3]) : 
        print("(",n+1,") : ",cosine_similarities[i]," , title : ",article_list[i]['title'])
        print("\t link : ",article_list[i]['link'])
    
    print("===[Top3 : Smallest Cosine Similarity]==========================================================================================")
    for n,i in enumerate(idx_tfidf[:3]) :
        print("(",n+1,") : ",cosine_similarities[i]," , title : ",article_list[i]['title'])
        print("\t link : ",article_list[i]['link'])
        
if __name__ == "__main__":
    main()
