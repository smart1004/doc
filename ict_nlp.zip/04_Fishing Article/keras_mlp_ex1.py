# 0. 사용할 패키지 불러오기
from keras.utils import np_utils
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense
from keras import layers
import numpy as np
from numpy import argmax

# 1. 데이터셋 생성하기

# 훈련셋과 시험셋 불러오기
(images_train, labels_train), (images_test, labels_test) = mnist.load_data()

# 데이터셋 전처리
images_train = images_train.reshape(60000, 784).astype('float32') / 255.0
images_test = images_test.reshape(10000, 784).astype('float32') / 255.0

# 원핫인코딩 (one-hot encoding) 처리
labels_train = np_utils.to_categorical(labels_train)
labels_test = np_utils.to_categorical(labels_test)

# 훈련셋과 검증셋 분리
images_val = images_train[:18000] # 훈련셋의 30%를 검증셋으로 사용
images_train = images_train[18000:]
labels_val = labels_train[:18000] # 훈련셋의 30%를 검증셋으로 사용
labels_train = labels_train[18000:]

# 2. 모델 구성하기
model = Sequential()
model.add(Dense(units=256, activation='relu'))
model.add(layers.Dropout(0.1))
model.add(Dense(units=256, activation='relu'))
model.add(Dense(units=256, activation='relu'))
model.add(Dense(units=10, activation='softmax'))

# 3. 모델 학습과정 설정하기
model.compile(loss='categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])

# 4. 모델 학습시키기
model.fit(images_train, labels_train, epochs=5, batch_size=32, validation_data=(images_val, labels_val))

# 5. 모델 평가하기
loss_and_metrics = model.evaluate(images_test, labels_test, batch_size=32)
print('')
print('loss_and_metrics : ' + str(loss_and_metrics))

# 6. 모델 사용하기
xhat_idx = np.random.choice(images_test.shape[0], 5)
xhat = images_test[xhat_idx]
yhat = model.predict_classes(xhat)

for i in range(5):
    print('True : ' + str(argmax(labels_test[xhat_idx[i]])) + ', Predict : ' + str(yhat[i]))
    
    
    
    
    
    
    
    
    
    
    
    
    
    