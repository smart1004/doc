# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 16:20:32 2018

@author: CAU
"""

# hihello 
# h: 0, i: 1, e: 2, l: 3, o: 4
import tensorflow as tf
import numpy as np

idx2char = ['h', 'i', 'e', 'l', 'o']
x_data = [[0, 1, 0, 2, 3, 3]] # hihell
y_data = [[1, 0, 2, 3, 3, 4]] # ihello
x_onehot = [[[1,0,0,0,0],
             [0,1,0,0,0],
             [1,0,0,0,0],
             [0,0,1,0,0],
             [0,0,0,1,0],
             [0,0,0,1,0]]]

num_classes = 5
input_dim = 5
h_size = 5 # hidden vector size
b_size = 1 # batch size
seq_length = 6

X = tf.placeholder(tf.float32, [None, seq_length, input_dim])
Y = tf.placeholder(tf.int32, [None, seq_length])

cell = tf.contrib.rnn.BasicLSTMCell(num_units=h_size, state_is_tuple=True)
initial_state = cell.zero_state(b_size, tf.float32)
model, _s = tf.nn.dynamic_rnn(cell, X, initial_state=initial_state, dtype=tf.float32)

model = tf.reshape(model, [b_size, seq_length, num_classes])
weights = tf.ones([b_size, seq_length])

cost = tf.reduce_mean(tf.contrib.seq2seq.sequence_loss(logits=model, targets=Y, weights=weights))
train = tf.train.AdamOptimizer(0.1).minimize(cost)

pred = tf.argmax(model, axis=2)

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for i in range(200):
        c, _ = sess.run([cost, train], feed_dict={X: x_onehot, Y: y_data})
        result = sess.run(pred, feed_dict={X: x_onehot})
        print(i, "cost: ", c, "pred: ", result)
        result_str = [idx2char[c] for c in np.squeeze(result)]
        print("Prediction String: ", ''.join(result_str))































