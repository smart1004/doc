from keras.preprocessing.text import text_to_word_sequence
x_train = '나는 머신러닝이 매우 좋아요'
print(text_to_word_sequence(x_train))
