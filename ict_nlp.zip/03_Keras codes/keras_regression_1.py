import numpy as np
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense

# data
x_train = [10, 18, 25, 36, 40, 58, 70, 86]
y_train = [50, 62, 74, 80, 82, 89, 90, 92]

# model
model = Sequential()
model.add(Dense(1, input_dim = 1)) # number of units in the input layer: 1

# learning methods
model.compile(loss='mse', optimizer='adam')

# training
model.fit(x_train, y_train, epochs=5000, verbose=1) # verbose, 1: show the training, 0: don't show the training
model.summary()
print(model.get_weights()) # print weight values

# evaluation
y_predict = model.predict(np.array([55])) # model result prediction when the input is 55
print(y_predict)

plt.scatter(x_train, y_train)
plt.plot(x_train, y_train)
plt.grid(True)
plt.show()
