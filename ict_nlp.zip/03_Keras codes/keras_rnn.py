# -*- coding: utf-8 -*-
"""
Created on Wed Oct 24 21:35:52 2018

@author: CAU, https://www.youtube.com/watch?v=iMIWee_PXl8
"""

from keras.models import Sequential
from keras.layers import LSTM
from sklearn.model_selection import train_test_split # pip install -U scikit-learn
import numpy as np
import matplotlib.pyplot as plt
data = [[[(i+j)/100] for i in range (5)] for j in range(100)]
target = [(i+5)/100 for i in range(100)]
#print(data)
#print(target)
data = np.array(data, dtype=float)
target = np.array(target, dtype=float)
x_train, x_test, y_train, y_test = train_test_split(data,target,test_size=0.2, random_state=4)
model=Sequential()
#model.add(LSTM(1,batch_input_shape=(None,5,1), return_sequences=False))
#model.add(LSTM(1,input_shape=(5,1), return_sequences=False))
model.add(LSTM(1, input_dim = 1, input_length = 5, return_sequences=False))
# line (25-26), two-layered LSTM
#model.add(LSTM(1,batch_input_shape=(None,5,1), return_sequences=True))
#model.add(LSTM(1,return_sequences=False))
model.compile(loss='mse', optimizer='adam', metrics=['accuracy'])
model.summary
history=model.fit(x_train,y_train, epochs=1000, validation_data=(x_test,y_test), verbose=0)
results = model.predict(x_test)
plt.scatter(range(20), results, c='r')
plt.scatter(range(20), y_test, c='g')
plt.show()
plt.plot(history.history['loss'])
plt.show()


