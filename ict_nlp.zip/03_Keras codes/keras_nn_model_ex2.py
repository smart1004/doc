import numpy as np
from keras.models import Sequential
from keras.layers import Dense

# data
x_train = np.array([[1, 5], [2, 6], [3, 7], [4, 8]])
y_train = np.array([[2, 10], [4 , 12], [6, 14], [8, 16]])

# model
model = Sequential()
model.add(Dense(1, input_shape = (2,))) # number of units in the input layer: 1
model.add(Dense(4)) # number of units in the hidden layer 1: 4
model.add(Dense(2)) # number of units in the output layer: 2

# learning methods
model.compile(loss='mse', optimizer='adam')

# training
model.fit(x_train, y_train, epochs=5000, verbose=1) # verbose, 1: show the training, 0: don't show the training
model.summary()
print(model.get_weights()) # print weight values

# evaluation
y_predict = model.predict(np.array([[5, 9], [6, 10]])) # model result prediction when the inputs are [5, 9] and [6, 10]
print(y_predict)
