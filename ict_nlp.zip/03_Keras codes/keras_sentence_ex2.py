from keras.preprocessing.text import Tokenizer

x_train = ['나는 머신러닝이 매우 좋아요',
	'너도 머신러닝이 좋은거 같아요',
	'나는 알고리즘이 더 좋아요',
	'너도 알고리즘이 별로인가요']

t = Tokenizer()
t.fit_on_texts(x_train)

print(t.word_counts) # 단어가 해당 문서에서 몇 번 사용되었는지 단어 개수 정보 출력
print(t.document_count) # 문서에 있는 문장의 수가 몇 개인지 출력
print(t.word_index) # 단어들에 인덱스를 자동으로 부여
print(t.word_docs) # 각 단어들이 몇 개의 문장들에 사용되었는지 출력

print(t.texts_to_matrix(x_train, mode='count')) # 문장들을 인코딩하여 벡터로 생성
