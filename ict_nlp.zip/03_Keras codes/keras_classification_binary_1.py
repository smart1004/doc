import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import SGD

# data
x_train = np.array([[170, 60], [180, 70], [185, 80], [177, 77], [167, 65], [150, 58], [164, 45], [168, 52], [173, 55], [167, 59]])
y_train = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])

# model
model = Sequential()
model.add(Dense(15, input_dim = 2, activation='sigmoid')) 
model.add(Dense(1, activation='sigmoid'))

# learning methods
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# training
model.fit(x_train, y_train, epochs=10000, verbose=0) # verbose, 1: show the training, 0: don't show the training
model.summary()
print(model.get_weights()) # print weight values

# evaluation
y_predict = model.predict(np.array([[161, 54]])) # model result prediction when the input is 55
print(y_predict)
