# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 15:22:25 2018

@author: CAU
"""

from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("/tmp/", one_hot=True)

import tensorflow as tf
import time
num_steps = 5000
b_size = 128
nH1 = 256
nH2 = 256
nH3 = 256

X = tf.placeholder("float",[None,784])
Y = tf.placeholder("float",[None,10])

def mlp(img):
    HL1 = tf.nn.relu(tf.add(tf.matmul(img,W['h1']),b['h1']))
    HL2 = tf.nn.relu(tf.add(tf.matmul(HL1,W['h2']),b['h2']))
    HL3 = tf.nn.relu(tf.add(tf.matmul(HL2,W['h3']),b['h3']))
    Out = tf.matmul(HL3,W['out'])+b['out']
    return Out

W = {
     'h1' : tf.Variable(tf.random_normal([784,nH1])),
     'h2' : tf.Variable(tf.random_normal([nH1,nH2])),
     'h3' : tf.Variable(tf.random_normal([nH2,nH3])),
     'out': tf.Variable(tf.random_normal([nH3,10]))
} 

b = {
     'h1' : tf.Variable(tf.random_normal([nH1])),
     'h2' : tf.Variable(tf.random_normal([nH2])),
     'h3' : tf.Variable(tf.random_normal([nH3])),
     'out': tf.Variable(tf.random_normal([10]))
} 

model_wo_softmax = mlp(X)
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=model_wo_softmax, labels=Y))
train = tf.train.AdamOptimizer(0.01).minimize(cost)

model = tf.nn.softmax(model_wo_softmax)
acc = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(model,1), tf.argmax(Y,1)), tf.float32))

with tf.Session() as sess:
    # Training
    t1 = time.time()
    sess.run(tf.global_variables_initializer())
    for step in range(num_steps):
        train_images, train_labels = mnist.train.next_batch(b_size)
        sess.run(train, feed_dict={X: train_images, Y: train_labels})
        if step % 500 == 0:
            print(step)
    t2 = time.time()
    # Testing
    print("Testing Acc: ", sess.run(acc, feed_dict={X: mnist.test.images, Y:mnist.test.labels}))
print("Time "+str(t2-t1)+" seconds")














