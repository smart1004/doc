# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 16:52:20 2018

@author: CAU
"""

# MNIST: 
# [1] 3*3 (8)
# [2] Pooling
# [3] 3*3 (16)
# [4] Pooling
# [5] Softmax

from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("/tmp/data/", one_hot=True)

import tensorflow as tf
import time

training_epochs = 10
b_size = 100
X = tf.placeholder(tf.float32, [None,784])
Y = tf.placeholder(tf.float32, [None,10])

X_img = tf.reshape(X, [-1,28,28,1])

# Convolution 1, 8 filters [3*3]
W1 = tf.Variable(tf.random_normal([3,3,1,8], stddev=0.01)) 
L1 = tf.conv2d(X_img, W1, strides=[1,1,1,1], padding='SAME')
L1 = tf.nn.relu(L1)
print(L1)
# Pooling
L1 = tf.nn.max_pool(L1,ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME')
print(L1)
# Convolution 2, 16 filters [3*3]
W2 = tf.Variable(tf.random_normal([3,3,8,16], stddev=0.01)) 
L2 = tf.conv2d(L1, W2, strides=[1,1,1,1], padding='SAME')
L2 = tf.nn.relu(L2)
print(L2)
# Pooling
L2 = tf.nn.max_pool(L2,ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME')
print(L2)

L2_flat = tf.reshape(L2, [-1,7*7*16])
W3 = tf.Variable(tf.random_normal([7*7*16, 10]))
b3 = tf.Variable(tf.random_normal([10]))

model_wo_softmax = tf.matmul(L2_flat, W3)+b3
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=model_wo_softmax, labels=Y))
train = tf.train.AdamOptimizer(0.01).minimize(cost)

model = tf.nn.softmax(model_wo_softmax)
acc = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(model,1), tf.argmax(Y,1)), tf.float32))

with tf.Session as sess:
    sess.run(tf.global_variables_initializer())
    t1=time.time()
    for epoch in range(training_epochs):
        total_batch = int(mnist.train.num_examples / b_size)
        for i in range(total_batch):
            train_images, train_labels = mnist.train.next_batch(b_size)
            sess.run(train, feed_dict = {X: train_images, Y: train_labels})
    t2=time.time()
    # Testing
    print("Testing Acc: ", sess.run(acc, feed_dict={X: mnist.test.images, Y:mnist.test.labels}))    
print("Time "+str(t2-t1)+" seconds")


















